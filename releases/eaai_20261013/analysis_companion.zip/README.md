# Supervision validation for low-resource hate-speech detection with translated training data

This companion contains the numerical results and verification code for the
manuscript and its supplement. Start here to check the complete set of analyses.

## Reproduce the reported statistics

Use Python 3.12 or later, install the dependencies, then run:

```sh
python -m pip install -r requirements.txt
python -B reproduce.py --output ../reproduction_results
```

Choose an output directory outside this companion. The command checks the file
checksums and verifies the main factorial comparisons, EXAONE and Gemma
supervision controls, KOLD and APEACH evaluations, instruction-boundary
comparison, human-audit summaries, and descriptive error analyses. The final
report is `verification.json` in the selected output directory. A successful run
reports `"status": "PASS"`.

The verification uses saved run-level metrics, integer confusion counts, and
aggregate annotation data. It reconstructs paired differences, pointwise
confidence intervals, and the specified Holm corrections. Human-audit interval
endpoints use the saved bootstrap estimates. Re-running training, translation,
annotation, or the original item-level bootstrap requires the corresponding
model environments and underlying text or response data.

## Find a result

Paths below are relative to `analysis/`. Tables refer to the current English
manuscript and supplement; S denotes a supplementary table.

| Manuscript result | Numerical files |
|---|---|
| Tables 5 and S32–S37: EXAONE supervision controls and target losses | `data/control_run_metrics.csv`, `data/control_paired_contrasts.csv`, `data/control_target_recall.csv`, `data/target_lw_*.csv` |
| Tables 6 and S41–S44: Gemma supervision controls | `data/gemma_20261010/` |
| Table 7 and Tables S4–S13: main factorial means and 44 paired comparisons | `data/run_metrics.csv`, `data/paired_contrasts.csv` |
| Table 8 and Tables S20–S27: class and target recall | `data/diagnostic_tables/subgroup_*.csv`, `data/target_recall_reproduction.csv` |
| Tables S15–S19: annotation transitions and label proportions | `data/diagnostic_tables/transition*.csv` |
| Figure 6 and Tables S29–S31: shared-text human audit | `data/annotation_audit_summary.csv`, `data/annotation_audit_statistics.json`, `data/human_reinforcement_summary.json`, `data/human_bootstrap_estimates.csv` |
| Table 9 and Tables S38–S40: original KOLD transfer evaluation | `data/kold_cell_metrics.csv`, `data/kold_contrasts.csv`, `data/kold_strata.csv` |
| Table 10(a) and Tables S45–S48: KOLD supervision controls | `data/kold_controls_20261010/` |
| Table 10(b) and Tables S49–S51: APEACH supervision controls | `data/apeach_controls_20261010/` |
| Table 11 and Tables S52–S56: instruction-boundary A/B comparison | `data/policy_boundary_20261010/` |
| Supplementary Section S13: comment error frequency and overlapping targets | `data/cpu_20261010/`, `data/target_lw_turnover*.csv` |
| Tables 1–4, S1–S3, S14 and S28: procedures, settings and development history | Manuscript and supplement; `data/model_metadata.json`, `data/execution_metadata.json`, `reproducibility/` support model and assignment details |

Each CSV directory includes the full condition or subgroup results described in
the supplement. In the external and boundary directories, `cells.csv` contains
run-level confusion counts, `arm_summaries.csv` contains condition means, and
`primary.csv` contains the specified comparisons. `reproducibility/README.md`
explains the original training-row identifiers and ordering.

## Read conditions and units

S uses inherited source labels. L uses task-guided relabels. W retains source
labels and weights each source-corpus/class cell to match its L class count.
P reassigns L labels within source-corpus/inherited-label strata. The translator
and annotator pathway is identified separately in each file.

F1, recall and accuracy use the 0–1 scale. Fields ending in `_gain_pp` use
percentage points. The human-audit CSV's agreement columns contain counts out
of `n`; JSON fields named `agreement_percent` use percentages. Target masks may
overlap. Import `signature_bits` as text to preserve leading zeros.

Holm correction is applied within each comparison family: 44 main contrasts;
four primary and 14 target contrasts for each within-corpus supervision study;
eight original KOLD contrasts; eight KOLD controls; eight APEACH controls; and
12 instruction-boundary contrasts. Descriptive comparisons have blank p fields.
An adjusted p value of 1 is a valid result of the Holm calculation. The
supplement specifies the historical zero/undefined conventions for secondary MCC.

## Protocols and access

The supplement provides translation messages (Section S2), annotation
instructions and their English translation (S3), and the four A/B additions
(S17). Offensive example wording is redacted in the public protocols. During
anonymous review, requests for the unredacted executed instructions can be
directed to the corresponding author through the journal's editorial office,
subject to the applicable data-use restrictions.

Obtain the original corpora from the distributors cited in the manuscript.
The numerical release contains text-free training assignments and aggregate
human responses; individual human response files remain confidential under
the audit's participant information. Dataset and model reuse follows each
provider's terms. A separate reuse license for this numerical release is pending.

## Versioned contents

`analysis/` preserves all 93 files of the verified numerical release, including
its earlier documentation and checksums. This README and the top-level command
provide the current entry point. `SHA256SUMS.txt` covers the complete companion.

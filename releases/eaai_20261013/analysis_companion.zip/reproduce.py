#!/usr/bin/env python3
"""Verify all numerical analyses accompanying the current manuscript."""
from pathlib import Path
import argparse
import hashlib
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'reproduction_results')
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        parser.error('Choose an output directory outside the companion.')
    expected = {}
    for line in (ROOT / 'SHA256SUMS.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        expected[name] = digest
    actual = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in ROOT.rglob('*') if p.is_file() and p != ROOT / 'SHA256SUMS.txt'}
    if any(p.is_symlink() for p in ROOT.rglob('*')) or actual != expected:
        raise ValueError('Companion files do not match SHA256SUMS.txt.')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH', None)
    subprocess.run([sys.executable, '-B', str(ROOT / 'analysis/reproduce_extended.py'),
                    '--output', str(output)], cwd=ROOT.parent, env=env, check=True)

if __name__ == '__main__':
    main()

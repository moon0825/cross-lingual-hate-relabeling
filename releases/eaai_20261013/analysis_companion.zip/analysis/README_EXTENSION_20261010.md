# Local numerical companion extension (2026-10-10)

This directory is prepared locally for a new submission package. This export
does not publish or update an external repository. The historical repository
base and the newly attached numerical extension have separate availability.

The 45 historical files are copied unchanged, including README.md,
SHA256SUMS.txt and reproduce.py. Their historical documentation describes that
base; this extension does not revise those files or their publication receipts.
SHA256SUMS_REINFORCEMENT.txt covers every file in this local directory except
itself. Use the new entrypoint for the whole companion:

```sh
python -B /path/to/companion/reproduce_extended.py --output /path/to/separate/output
```

Install the historical requirements.txt dependencies first. The standalone
CPU checker uses only the Python standard library:

```sh
python -B /path/to/companion/reproduce_cpu_20261010.py --output /path/to/separate/cpu_output
```

Six added CSV files in data/cpu_20261010 contain descriptive paired L-versus-W
error-frequency and seven-target-signature aggregates for retrieved EXAONE
translations with EXAONE relabels. The evaluation reference remains the original
human labels: 9,997 comments, including 3,198 hate and 6,799 non-hate comments,
two classifiers and 23 matched repetitions. They add no model training, p values,
threshold selection or independent-item-repeat tests.

The checker reconstructs the recovery/new-error marginal frequencies and their
CDF and inclusive survival probabilities from the historical joint frequency
histograms. All 0..23 bins, including zero-frequency bins, are present. It
checks every one of 128 disjoint seven-bit signatures for every model/repetition,
their status partitions, true-positive counts, means and cardinality summaries,
and sums them back to the seven overlapping target-positive masks and overall
hate recall. These sums are compared with the historical public turnover and
target-recall tables. The all-zero signature and every zero-support combination
are retained. Recalls with zero support are blank, not zero.

Read signature_bits as a seven-character string. Left-to-right target order is
gender, age, race_or_region_of_origin, religion, politics, occupation, disability.
Code 1 is 1000000 and code 2 is 0100000. Spreadsheet import must preserve leading
zeros. The checker uses CSV strings, not numeric inference of these fields.

The added extension includes aggregate counts and verification code only. It
does not include original comments, translated texts, individual human responses,
private evaluation identifiers, prediction rows, credentials or publisher full
texts. The unchanged historical base retains its documented training-assignment
exports. Public aggregate arithmetic cannot independently recover private mask
assignments or prediction alignment; those inputs were checked in a separate
independent review before export. The public checker does not repeat that review.

The added Gemma extension contains six aggregate CSVs in data/gemma_20261010:
184 newly fitted S/L/W/P cell confusion matrices,1288 target-positive N/TP/recall
rows,4 primary macro contrasts with Holm4,14 target contrasts with Holm14,
6 descriptive contrasts without inferential p values, and8 arm means/SDs.
The companion checker forms macro-F1 as an exact rational function of integer
confusion counts, subtracts exact fractions before converting the paired change
to float, and uses integer target TP differences before division by fixed N.
It adds no epsilon cutoff. Paired23-repeat statistics use Student-t with22 degrees
of freedom, with the
two multiplicity families kept separate. A constant nonzero difference has an
undefined estimated-variance probability, shown blank; zero constant differences
retain p=1. Pointwise intervals are not simultaneous intervals or item-level
independent confirmation. The original human evaluation reference is unchanged.

The valid completed matrix has184 cells. Preserved technical training attempts
from the prior failed execution total1, are excluded from that matrix, and
are disclosed separately; total optimizer attempts are185. No historical fit cell
is reused as a new cell. Full FP32 checkpoint bytes were verified on the leased
B200 worker; numeric results and byte/inventory receipts were retrieved to the
controller. Raw weight storage is a separate temporary user-authorized exception
and the public aggregates do not claim those weights were copied to the controller.

These newly attached aggregates were converted only after an actual complete
analysis and independent numeric review, then checked by a separate actual
public-export review binding each CSV and checker byte. The portable arithmetic
does not replace private prediction/target-assignment review. This is a local
attachment and does not assert external repository publication or final submission.

The new completed attachments additionally include all eleven KOLD-control,
seven APEACH-control and twelve policy A/B aggregate CSVs. Their original
human-reference populations and all adverse/null/undefined outcomes are retained.
KOLD Holm8, APEACH Holm8 and policy Holm12 are separate families; native/subgroup
and freshly matched internal EXAONE diagnostics do not add inferential families.
The standalone checker verifies exact confusion-count arithmetic, paired23-seed
statistics and pointwise intervals. It does not reconstruct the private item
alignment, original training, teacher vectors or human-response rows.
The policy turnover unique-item map is withheld; only count-level turnover and
reused native-reference distributions are attached. Native2000 judgments are
reused development diagnostics, not new independent semantic validation.
Publication of these new attachments or model weights is not asserted here.

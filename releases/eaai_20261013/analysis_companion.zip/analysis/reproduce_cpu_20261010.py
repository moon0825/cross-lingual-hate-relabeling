#!/usr/bin/env python3
"""Check the descriptive CPU extension using released aggregate tables only.

This file is copied unchanged into the local numerical companion as
reproduce_cpu_20261010.py. It uses the Python standard library and never loads
source comments, individual judgments, prediction rows or the author generator.
The target-bit order is left to right in TARGETS; code 1 is 1000000.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path

MODELS = ("kcelectra", "xlmr")
SEEDS = tuple(range(20260901, 20260924))
TARGETS = ("gender", "age", "race_or_region_of_origin", "religion",
           "politics", "occupation", "disability")
STRATA = TARGETS + ("overall_hate", "overall_non_hate")
HATE_STRATA = TARGETS + ("overall_hate",)
STATUSES = ("both_correct", "recovered_by_L", "new_errors_under_L", "both_wrong")
FREQUENCY_STATUSES = ("recovered_by_L", "new_errors_under_L")
CPU_FILES = ("error_frequency_complete.csv", "error_frequency_summary.csv",
             "target_signature_by_repeat.csv", "target_signature_summary.csv",
             "target_cardinality_summary.csv", "signature_reconstruction.csv")


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.maximum_difference = defaultdict(float)

    def equal(self, observed, expected, category, identity):
        if observed != expected:
            raise ValueError(f"{category} differs at {identity}: {observed!r} != {expected!r}")
        self.counts[category] += 1

    def number(self, observed, expected, category, identity):
        if expected is None:
            self.equal(observed, "", category + "_empty_support", identity)
            return
        try:
            value = float(observed)
        except (ValueError, TypeError) as exc:
            raise ValueError(f"Non-numeric {category} at {identity}") from exc
        expected = float(expected)
        difference = abs(value - expected)
        tolerance = max(1e-12, 2 * math.ulp(expected))
        if not math.isfinite(value) or difference > tolerance:
            raise ValueError(f"{category} differs at {identity} by {difference}")
        self.counts[category] += 1
        self.maximum_difference[category] = max(self.maximum_difference[category], difference)


def integer(row, column):
    value = row[column]
    if not value.isdigit():
        raise ValueError(f"Expected a non-negative integer in {column}: {value!r}")
    return int(value)


def table(path):
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f"Missing/duplicate CSV columns in {path.name}")
        rows = list(reader)
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError(f"Malformed CSV row in {path.name}")
    return rows


def keyed(rows, columns, expected, name, checks):
    result = {}
    for row in rows:
        key = tuple(row[column] for column in columns)
        if key in result:
            raise ValueError(f"Duplicate {name} row: {key}")
        result[key] = row
    checks.equal(set(result), set(expected), name + "_complete_grid", name)
    return result


def string_grid(*dimensions):
    return {tuple(str(value) for value in key) for key in itertools.product(*dimensions)}


def signature_metadata(code):
    bits = "".join("1" if code & (1 << index) else "0" for index in range(7))
    names = [name for index, name in enumerate(TARGETS) if code & (1 << index)]
    return bits, ";".join(names) or "none", len(names)


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(root, output=None):
    root = Path(root).resolve()
    data, cpu = root / "data", root / "data/cpu_20261010"
    checks = Checks()
    inputs = {name: table(cpu / name) for name in CPU_FILES}
    history_names = ("target_lw_item_turnover_histograms.csv", "target_lw_turnover_by_repeat.csv",
                     "target_lw_turnover_summary.csv", "target_recall_reproduction.csv")
    history = {name: table(data / name) for name in history_names}

    # The historical joint histogram independently supplies both marginal
    # frequency distributions. Explicit zero bins are constructed before use.
    joint = defaultdict(list)
    joint_keys = set()
    for row in history[history_names[0]]:
        key = row["model"], row["stratum"]
        counts = tuple(integer(row, status) for status in STATUSES)
        identity = key + counts
        if identity in joint_keys:
            raise ValueError(f"Duplicate historical joint-histogram bin: {identity}")
        joint_keys.add(identity)
        checks.equal(sum(counts), 23, "joint_status_partition", identity)
        frequency = integer(row, "frequency")
        if frequency <= 0:
            raise ValueError("Historical joint-histogram bins must have positive frequency")
        joint[key].append((counts, frequency))
    checks.equal(set(joint), set(itertools.product(MODELS, STRATA)), "joint_strata", "all")
    supports = {key: sum(frequency for _, frequency in bins) for key, bins in joint.items()}
    for stratum in STRATA:
        checks.equal(supports[MODELS[0], stratum], supports[MODELS[1], stratum],
                     "shared_stratum_support", stratum)
        if supports[MODELS[0], stratum] <= 0:
            raise ValueError("Released target and class strata must have positive support")

    old_repeat = keyed(history[history_names[1]], ("model", "repeat_seed", "stratum"),
                       string_grid(MODELS, SEEDS, STRATA), "historical_turnover", checks)
    old_summary = keyed(history[history_names[2]], ("model", "stratum"),
                        string_grid(MODELS, STRATA), "historical_turnover_summary", checks)
    old_recall = keyed(history[history_names[3]], ("model", "repeat_seed", "arm", "target"),
                       string_grid(MODELS, SEEDS, ("S", "L", "W", "P"), TARGETS),
                       "historical_target_recall", checks)
    for (model, seed, stratum), row in old_repeat.items():
        n = supports[model, stratum]
        counts = {status: integer(row, status) for status in STATUSES}
        checks.equal(integer(row, "n_distinct_items"), n, "historical_repeat_support", (model, seed, stratum))
        checks.equal(sum(counts.values()), n, "historical_repeat_partition", (model, seed, stratum))
        checks.equal(integer(row, "gold_binary"), int(stratum != "overall_non_hate"),
                     "historical_repeat_gold_class", (model, seed, stratum))
        w = (counts["both_correct"] + counts["new_errors_under_L"]) / n
        l = (counts["both_correct"] + counts["recovered_by_L"]) / n
        for column, expected in (("W_correct_rate", w), ("L_correct_rate", l),
                                 ("L_minus_W_correct_rate", l - w),
                                 ("recovery_minus_new_error_over_n",
                                  (counts["recovered_by_L"] - counts["new_errors_under_L"]) / n)):
            checks.number(row[column], expected, "historical_repeat_rate", (model, seed, stratum, column))
    for (model, stratum), bins in joint.items():
        summary = old_summary[model, stratum]
        n = supports[model, stratum]
        for column in ("n", "n_distinct_items"):
            checks.equal(integer(summary, column), n, "historical_summary_support", (model, stratum, column))
        checks.equal(integer(summary, "paired_repeats"), 23, "historical_summary_repeats", (model, stratum))
        for index, status in enumerate(STATUSES):
            item_repeat_count = sum(counts[index] * frequency for counts, frequency in bins)
            by_repeat_count = sum(integer(old_repeat[model, str(seed), stratum], status) for seed in SEEDS)
            checks.equal(by_repeat_count, item_repeat_count, "joint_vs_repeat_counts", (model, stratum, status))
            checks.equal(integer(summary, status + "_item_repeat_observations"), item_repeat_count,
                         "joint_vs_historical_summary_counts", (model, stratum, status))
            checks.number(summary[status + "_mean_per_repeat"], item_repeat_count / 23,
                          "joint_vs_historical_summary_means", (model, stratum, status))

    frequency = keyed(inputs[CPU_FILES[0]], ("model", "stratum", "status", "paired_repeats_with_status"),
                      string_grid(MODELS, STRATA, FREQUENCY_STATUSES, range(24)), "frequency", checks)
    frequency_summary = keyed(inputs[CPU_FILES[1]], ("model", "stratum", "status"),
                              string_grid(MODELS, STRATA, FREQUENCY_STATUSES), "frequency_summary", checks)
    reconstructed_frequency, reconstructed_frequency_summary = [], []
    for model, stratum, status in itertools.product(MODELS, STRATA, FREQUENCY_STATUSES):
        identity = model, stratum, status
        n = supports[model, stratum]
        bins = [0] * 24
        position = STATUSES.index(status)
        for counts, multiplicity in joint[model, stratum]:
            bins[counts[position]] += multiplicity
        checks.equal(sum(bins), n, "frequency_mass", identity)
        for k in range(24):
            row = frequency[identity + (str(k),)]
            expected = dict(model=model, stratum=stratum, status=status, paired_repeats_with_status=k,
                            n_distinct_items=n, frequency=bins[k], fraction=bins[k] / n,
                            cdf_at_most_k=sum(bins[:k + 1]) / n,
                            survival_at_least_k=sum(bins[k:]) / n)
            for column in ("n_distinct_items", "frequency"):
                checks.equal(integer(row, column), expected[column], "frequency_bin_count", identity + (k, column))
            for column in ("fraction", "cdf_at_most_k", "survival_at_least_k"):
                checks.number(row[column], expected[column], "frequency_probability", identity + (k, column))
            checks.number(float(row["cdf_at_most_k"]) + float(row["survival_at_least_k"]),
                          1 + bins[k] / n, "inclusive_cdf_survival_identity", identity + (k,))
            reconstructed_frequency.append(expected)
        total = sum(k * bins[k] for k in range(24))
        expected = dict(model=model, stratum=stratum, status=status, n_distinct_items=n, never=bins[0],
                        at_least_once=n - bins[0], all_23_repeats=bins[23], item_repeat_count=total,
                        mean_count_per_repeat=total / 23)
        row = frequency_summary[identity]
        for column in ("n_distinct_items", "never", "at_least_once", "all_23_repeats", "item_repeat_count"):
            checks.equal(integer(row, column), expected[column], "frequency_summary_count", identity + (column,))
        checks.number(row["mean_count_per_repeat"], expected["mean_count_per_repeat"],
                      "frequency_summary_mean", identity)
        reconstructed_frequency_summary.append(expected)

    signatures = keyed(inputs[CPU_FILES[2]], ("model", "repeat_seed", "signature_code"),
                       string_grid(MODELS, SEEDS, range(128)), "signature_repeat", checks)
    signature_supports, counts_by_signature = {}, {}
    for (model, seed, code_string), row in signatures.items():
        code = int(code_string)
        bits, names, cardinality = signature_metadata(code)
        identity = model, seed, code
        checks.equal(row["signature_bits"], bits, "signature_seven_character_bits", identity)
        checks.equal(row["targets"], names, "signature_target_names", identity)
        checks.equal(integer(row, "target_count"), cardinality, "signature_cardinality", identity)
        n = integer(row, "hate_n")
        signature_supports.setdefault(code, n)
        checks.equal(n, signature_supports[code], "signature_shared_fixed_support", identity)
        counts = tuple(integer(row, status) for status in STATUSES)
        counts_by_signature[model, int(seed), code] = counts
        checks.equal(sum(counts), n, "signature_status_partition", identity)
        w_tp, l_tp = counts[0] + counts[2], counts[0] + counts[1]
        checks.equal(integer(row, "W_tp"), w_tp, "signature_W_true_positives", identity)
        checks.equal(integer(row, "L_tp"), l_tp, "signature_L_true_positives", identity)
        checks.number(row["L_minus_W_recall"], (l_tp - w_tp) / n if n else None,
                      "signature_repeat_recall_difference", identity)
    hate_n = sum(signature_supports.values())
    checks.equal(hate_n, supports[MODELS[0], "overall_hate"], "signature_partition_hate_population", "all128")

    reconstruction = keyed(inputs[CPU_FILES[5]], ("model", "repeat_seed", "arm", "stratum"),
                           string_grid(MODELS, SEEDS, ("W", "L"), HATE_STRATA), "recall_reconstruction", checks)
    reconstructed_recall = []
    for model, seed, stratum in itertools.product(MODELS, SEEDS, HATE_STRATA):
        index = TARGETS.index(stratum) if stratum in TARGETS else None
        codes = [code for code in range(128) if index is None or code & (1 << index)]
        n = sum(signature_supports[code] for code in codes)
        summed = tuple(sum(counts_by_signature[model, seed, code][position] for code in codes)
                       for position in range(4))
        identity = model, seed, stratum
        checks.equal(n, supports[model, stratum], "signature_mask_sum_support", identity)
        old = old_repeat[model, str(seed), stratum]
        for position, status in enumerate(STATUSES):
            checks.equal(summed[position], integer(old, status), "signature_mask_sum_vs_historical_status", identity + (status,))
        for arm, tp in (("W", summed[0] + summed[2]), ("L", summed[0] + summed[1])):
            key = model, str(seed), arm, stratum
            row = reconstruction[key]
            expected = dict(model=model, repeat_seed=seed, arm=arm, stratum=stratum, n=n,
                            reconstructed_tp=tp, direct_tp=tp, reconstructed_recall=tp / n,
                            original_recall=tp / n)
            for column in ("n", "reconstructed_tp", "direct_tp"):
                checks.equal(integer(row, column), expected[column], "recall_reconstruction_count", key + (column,))
            for column in ("reconstructed_recall", "original_recall"):
                checks.number(row[column], tp / n, "recall_reconstruction_rate", key + (column,))
            if stratum in TARGETS:
                original = old_recall[model, str(seed), arm, stratum]
                checks.equal(integer(original, "hate_n"), n, "original_target_recall_support", key)
                for column in ("recall", "original_analysis_recall", "original_csv_recall"):
                    checks.number(original[column], tp / n, "signature_vs_original_target_recall", key + (column,))
            else:
                checks.number(old[arm + "_correct_rate"], tp / n, "signature_vs_original_overall_recall", key)
            reconstructed_recall.append(expected)

    summary = keyed(inputs[CPU_FILES[3]], ("model", "signature_code"),
                    string_grid(MODELS, range(128)), "signature_summary", checks)
    cardinality = keyed(inputs[CPU_FILES[4]], ("model", "target_count"),
                        string_grid(MODELS, range(8)), "cardinality_summary", checks)
    reconstructed_signature_summary, reconstructed_cardinality_summary = [], []

    def check_aggregate(row, codes, model, identity, kind):
        n = sum(signature_supports[code] for code in codes)
        totals = tuple(sum(counts_by_signature[model, seed, code][position]
                           for code in codes for seed in SEEDS) for position in range(4))
        checks.equal(integer(row, "hate_n"), n, kind + "_support", identity)
        expected = {"hate_n": n}
        for position, status in enumerate(STATUSES):
            column = status + "_mean_per_repeat"
            expected[column] = totals[position] / 23
            checks.number(row[column], expected[column], kind + "_status_mean", identity + (status,))
        w = (totals[0] + totals[2]) / (23 * n) if n else None
        l = (totals[0] + totals[1]) / (23 * n) if n else None
        delta = (totals[1] - totals[2]) / (23 * n) if n else None
        for column, value in (("W_recall_mean", w), ("L_recall_mean", l), ("L_minus_W_recall_mean", delta)):
            checks.number(row[column], value, kind + "_recall_mean", identity + (column,))
            expected[column] = value if value is not None else ""
        return expected

    for model, code in itertools.product(MODELS, range(128)):
        identity = model, str(code)
        row = summary[identity]
        bits, names, count = signature_metadata(code)
        checks.equal(row["signature_bits"], bits, "signature_summary_bits", identity)
        checks.equal(row["targets"], names, "signature_summary_targets", identity)
        checks.equal(integer(row, "target_count"), count, "signature_summary_cardinality", identity)
        expected = dict(model=model, signature_code=code, signature_bits=bits, targets=names, target_count=count)
        expected.update(check_aggregate(row, [code], model, identity, "signature_summary"))
        reconstructed_signature_summary.append(expected)
    for model, count in itertools.product(MODELS, range(8)):
        identity = model, str(count)
        codes = [code for code in range(128) if signature_metadata(code)[2] == count]
        expected = dict(model=model, target_count=count)
        expected.update(check_aggregate(cardinality[identity], codes, model, identity, "cardinality_summary"))
        reconstructed_cardinality_summary.append(expected)

    input_paths = [cpu / name for name in CPU_FILES] + [data / name for name in history_names]
    report = {
        "status": "PASS", "scope": "Descriptive EXAONE L versus W; fixed original human evaluation; aggregate-table consistency.",
        "implementation": "Standard-library independent arithmetic; no author generator imported or executed.",
        "checks_by_category": dict(sorted(checks.counts.items())),
        "maximum_absolute_differences": dict(sorted(checks.maximum_difference.items())),
        "numeric_policy": "Integer counts exact; floats within max(1e-12, two binary-float ULPs). Empty-support recalls must be blank.",
        "input_files": [{"path": path.relative_to(root).as_posix(),
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in input_paths],
        "frequency_rows": len(frequency), "signature_repeat_rows": len(signatures),
        "signature_codes_per_model_and_repeat": 128, "observed_signatures": sum(n > 0 for n in signature_supports.values()),
        "recall_reconstructions": len(reconstruction), "human_gold_hate_n": hate_n,
        "human_gold_non_hate_n": supports[MODELS[0], "overall_non_hate"],
        "targets_in_bit_order": list(TARGETS), "signature_bits_read_as_strings": True,
        "zero_support_and_all_zero_signature_retained": True, "frequency_zero_bins_retained": True,
        "new_training_or_model_calls": 0, "new_statistical_tests": 0,
        "limits": "Public aggregates cannot independently recover individual mask assignments or rerun private prediction alignment. Those were reviewed separately before export. No causal, semantic-gold or independent-item-repeat inference is added."
    }
    if output is not None:
        output = Path(output).resolve()
        if output == root or root in output.parents:
            raise ValueError("Use an output directory outside the companion to preserve its checksums")
        output.mkdir(parents=True, exist_ok=True)
        for name, rows in ((CPU_FILES[0], reconstructed_frequency), (CPU_FILES[1], reconstructed_frequency_summary),
                           (CPU_FILES[3], reconstructed_signature_summary), (CPU_FILES[4], reconstructed_cardinality_summary),
                           (CPU_FILES[5], reconstructed_recall)):
            write_csv(output / name, rows)
        (output / "verification.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent,
                        help="Numerical companion directory containing data/cpu_20261010")
    parser.add_argument("--output", type=Path, default=Path.cwd() / "cpu_reproduction_outputs_20261010",
                        help="Reconstructed results; choose a directory outside the companion")
    args = parser.parse_args()
    print(json.dumps(run(args.root, args.output), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

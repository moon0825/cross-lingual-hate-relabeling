#!/usr/bin/env python3
"""Verify released aggregate arithmetic for three separate comparison families.

This checker reads only the named CSV tables. It reconstructs metrics and paired
statistics from integer confusion counts. It does not establish the provenance,
alignment or scientific validity of the unreleased item-level inputs.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
import csv
from fractions import Fraction
import hashlib
import itertools
import io
import json
import math
from pathlib import Path
import re

PATHS = ("exaone", "gemma4")
MODELS = ("kcelectra", "xlmr")
SEEDS = tuple(range(20260901, 20260924))
CONTROL_ARMS = ("S", "L", "W", "P")
POLICY_ARMS = ("A", "B")
CORPORA = ("KHATERS", "KOLD", "APEACH")
POPULATIONS = {"KHATERS": (6799, 3198), "KOLD": (27776, 12353), "APEACH": (1848, 1919)}
TARGETS = ("gender", "age", "race_or_region_of_origin", "religion", "politics", "occupation", "disability")
TARGET_SUPPORT = (232, 102, 893, 46, 1790, 365, 99)
TOPICS = {"Education": (217, 187), "Gender sterotypes": (191, 220),
          "Disabled": (184, 170), "Age and social status": (210, 207),
          "Origin and residence": (207, 173), "Sexual harassment": (106, 190),
          "Nationality": (159, 206), "Diets": (230, 163),
          "Appearance": (202, 236), "Racism": (142, 167)}
# Complete original native-component inventory, populated from the reviewed
# aggregate class supports. Components overlap; source and OFF_TGT partition.
KOLD_GROUPS = {
    ('source', 'naver_news'): (14009, 7831),
    ('source', 'youtube'): (13767, 4522),
    ('OFF_TGT', 'OFF=false|TGT=null'): (19904, 0),
    ('OFF_TGT', 'OFF=true|TGT=group'): (0, 12353),
    ('OFF_TGT', 'OFF=true|TGT=individual'): (3889, 0),
    ('OFF_TGT', 'OFF=true|TGT=other'): (1399, 0),
    ('OFF_TGT', 'OFF=true|TGT=untargeted'): (2584, 0),
    ('GRP_component', 'gender-LGBTQ+'): (0, 1310),
    ('GRP_component', 'gender-female'): (0, 1129),
    ('GRP_component', 'gender-feminist'): (0, 80),
    ('GRP_component', 'gender-male'): (0, 590),
    ('GRP_component', 'gender-others'): (0, 108),
    ('GRP_component', 'gender-queer'): (0, 21),
    ('GRP_component', 'others-age'): (0, 62),
    ('GRP_component', 'others-disability'): (0, 24),
    ('GRP_component', 'others-disease'): (0, 8),
    ('GRP_component', 'others-feminist'): (0, 1383),
    ('GRP_component', 'others-others'): (0, 969),
    ('GRP_component', 'others-physical_appearance'): (0, 2),
    ('GRP_component', 'others-socioeconomic_status'): (0, 88),
    ('GRP_component', 'politics-conservative'): (0, 314),
    ('GRP_component', 'politics-others'): (0, 650),
    ('GRP_component', 'politics-progressive'): (0, 1046),
    ('GRP_component', 'race-asian'): (0, 43),
    ('GRP_component', 'race-black'): (0, 175),
    ('GRP_component', 'race-chinese'): (0, 473),
    ('GRP_component', 'race-indian'): (0, 173),
    ('GRP_component', 'race-korean_chinese'): (0, 459),
    ('GRP_component', 'race-others'): (0, 1593),
    ('GRP_component', 'race-southeast_asian'): (0, 81),
    ('GRP_component', 'race-white'): (0, 94),
    ('GRP_component', 'religion-buddhism'): (0, 17),
    ('GRP_component', 'religion-catholic'): (0, 57),
    ('GRP_component', 'religion-christian'): (0, 518),
    ('GRP_component', 'religion-islam'): (0, 1050),
    ('GRP_component', 'religion-others'): (0, 91),
    ('GRP_component', 'sexual_orientation-homosexual'): (0, 25),
    ('GRP_component', 'sexual_orientation-others'): (0, 8),
}
METRICS = ("macro_f1", "balanced_accuracy", "mcc", "non_hate_precision",
           "non_hate_recall", "non_hate_f1", "hate_precision", "hate_recall",
           "hate_f1", "predicted_hate_rate")
EXTRA_METRICS = ("false_positive_rate", "false_negative_rate")
CELL_FIELDS = ("tn", "fp", "fn", "tp", "n", "macro_f1", "macro_f1_numerator",
               "macro_f1_denominator", "non_hate_precision", "non_hate_recall",
               "non_hate_f1", "hate_precision", "hate_recall", "hate_f1",
               "balanced_accuracy", "mcc", "predicted_hate_rate")
NULLABLE_CELL_FIELDS = CELL_FIELDS + ("negative_reference_n", "positive_reference_n",
                                      *EXTRA_METRICS, "errors", "error_rate")
ID_FIELDS = ("path", "model", "repeat_seed", "arm")
PAIR_FIELDS = ("n", "mean", "sd", "ci95_pointwise")
KOLD_FILES = ("cells.csv", "arm_summaries.csv", "primary.csv", "S_references_descriptive.csv",
              "strata_cells.csv", "strata_summaries.csv", "strata_contrasts_descriptive.csv",
              "internal_EXAONE_cells.csv", "internal_EXAONE_arm_summaries.csv",
              "internal_EXAONE_L_W_L_P_descriptive.csv", "internal_EXAONE_S_references_descriptive.csv")
APEACH_FILES = ("cells.csv", "arm_summaries.csv", "primary.csv", "S_references_descriptive.csv",
                "writer_topic_cells.csv", "writer_topic_summaries.csv", "writer_topic_contrasts_descriptive.csv")
POLICY_FILES = ("cells.csv", "arm_summaries.csv", "primary.csv", "strata_cells.csv",
                "strata_summaries.csv", "strata_contrasts_descriptive.csv",
                "annotation_turnover_summary.csv", "annotation_turnover_by_repetition.csv",
                "native2000_diagnostic_cells.csv", "native2000_diagnostic_binary_transitions_by_reference_class.csv",
                "native2000_diagnostic_all13_score_distributions.csv", "native2000_diagnostic_teacher_target_presence.csv")
FILES = {"KOLD": KOLD_FILES, "APEACH": APEACH_FILES, "POLICY_AB": POLICY_FILES}
FAMILY_IDS = {"KOLD": "new_KOLD_assignment_controls_8", "APEACH": "new_APEACH_assignment_controls_8",
              "POLICY_AB": "new_policy_boundary_total_learning_12"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value):
    require(isinstance(value, str) and re.fullmatch(r"0|[1-9][0-9]*", value), "Nonnegative integer required")
    return int(value)


def literal(value):
    require(isinstance(value, str) and len(value) <= 16384, "Invalid aggregate literal")
    try:
        tree = ast.parse(value, mode="eval")
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                keys = [ast.literal_eval(k) for k in node.keys]
                require(len(keys) == len(set(keys)), "Duplicate aggregate dictionary key")
        return ast.literal_eval(tree)
    except (SyntaxError, TypeError, ValueError) as exc:
        raise ValueError("Invalid aggregate literal") from exc


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.max_difference = Counter()

    def equal(self, actual, expected, label):
        require(type(actual) is type(expected) and actual == expected, f"Value differs: {label}")
        self.counts[label.split(":", 1)[0]] += 1

    def number(self, text, expected, label):
        if expected is None:
            require(text == "", f"Undefined metric must be blank: {label}")
        else:
            try:
                value = float(text)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid numeric value: {label}") from exc
            require(math.isfinite(value), f"Nonfinite numeric value: {label}")
            tolerance = max(2e-12, 8 * math.ulp(float(expected)))
            if "p_raw" in label or "p_holm" in label:
                require(math.isfinite(expected) and 0 <= expected <= 1,
                        f"Invalid expected probability: {label}")
                require(0 <= value <= 1, f"Probability outside [0,1]: {label}")
                require((value == 0) == (expected == 0), f"Probability zero endpoint differs: {label}")
                if value == 1 or expected == 1:
                    require(abs(value - expected) <= 8 * math.ulp(1.0),
                            f"Probability one boundary differs: {label}")
                tolerance = max(abs(expected) * 1e-8, 8 * math.ulp(float(expected)))
            delta = abs(value - expected)
            require(delta <= tolerance, f"Numeric value differs: {label}")
            self.max_difference[label.split(":", 1)[0]] = max(self.max_difference[label.split(":", 1)[0]], delta)
        self.counts[label.split(":", 1)[0]] += 1


def table(folder, name, schema):
    path = folder / name
    require(path.is_file() and not path.is_symlink(), f"Missing regular aggregate: {name}")
    data = path.read_bytes()
    text = data.decode("utf-8")
    require(not re.search(r"(?:/home/|/Users/|[A-Za-z]:\\\\Users\\\\|-----BEGIN .*PRIVATE KEY-----|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})", text, re.I),
            "Private content is not an aggregate input")
    reader = csv.DictReader(io.StringIO(text, newline=""))
    require(tuple(reader.fieldnames or ()) == tuple(schema), f"Exact column order differs: {name}")
    rows = list(reader)
    require(all(None not in row and all(v is not None for v in row.values()) for row in rows), f"Malformed CSV: {name}")
    return rows, {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def keyed(rows, columns, expected, label):
    expected = [tuple(map(str, k)) for k in expected]
    result = {}
    for row in rows:
        key = tuple(row[c] for c in columns)
        require(key not in result, f"Duplicate identity: {label}")
        result[key] = row
    require(set(result) == set(expected), f"Incomplete or wrong identity grid: {label}")
    require(list(result) == expected, f"Identity row order differs: {label}")
    return result


def grid(*parts):
    return itertools.product(*parts)


def metrics(tn, fp, fn, tp, nullable=False, extras=False):
    require(all(type(x) is int and x >= 0 for x in (tn, fp, fn, tp)), "Invalid confusion counts")
    n0, n1 = tn + fp, fn + tp
    require(n0 + n1 > 0, "Empty population")
    def ratio(a, b):
        return Fraction(a, b) if b else Fraction(0)
    macro = ratio(tp, 2 * tp + fp + fn) + ratio(tn, 2 * tn + fp + fn)
    mcc_denom = (tp + fp) * n1 * n0 * (tn + fn)
    row = dict(tn=tn, fp=fp, fn=fn, tp=tp, n=n0+n1, macro_f1=float(macro),
               macro_f1_numerator=macro.numerator, macro_f1_denominator=macro.denominator,
               non_hate_precision=float(ratio(tn, tn+fn)), non_hate_recall=float(ratio(tn, n0)),
               non_hate_f1=float(ratio(2*tn, 2*tn+fp+fn)), hate_precision=float(ratio(tp, tp+fp)),
               hate_recall=float(ratio(tp, n1)), hate_f1=float(ratio(2*tp, 2*tp+fp+fn)),
               balanced_accuracy=float((ratio(tn, n0)+ratio(tp, n1))/2),
               mcc=(tp*tn-fp*fn)/math.sqrt(mcc_denom) if mcc_denom else 0.0,
               predicted_hate_rate=float(ratio(tp+fp, n0+n1)))
    if nullable:
        for name, denom in (("non_hate_precision", tn+fn), ("non_hate_recall", n0),
                            ("hate_precision", tp+fp), ("hate_recall", n1),
                            ("balanced_accuracy", n0*n1), ("mcc", mcc_denom)):
            if not denom:
                row[name] = None
    if extras:
        row.update(negative_reference_n=n0, positive_reference_n=n1,
                   false_positive_rate=fp/n0 if n0 else None, false_negative_rate=fn/n1 if n1 else None,
                   errors=fp+fn, error_rate=(fp+fn)/(n0+n1))
    return row


def mean_sd(values):
    require(len(values) == 23, "All23 paired repetitions required")
    defined = [x for x in values if x is not None]
    require(all(math.isfinite(x) for x in defined), "Nonfinite summary input")
    if len(defined) != 23:
        return dict(mean=None, sd=None, defined_repetitions=len(defined))
    mean = values[0] if len(set(values)) == 1 else math.fsum(values)/23
    sd = 0.0 if len(set(values)) == 1 else math.sqrt(math.fsum((x-mean)**2 for x in values)/22)
    return dict(mean=float(mean), sd=sd, defined_repetitions=23)


def paired(values):
    from scipy.stats import t
    summary = mean_sd(values)
    require(summary["defined_repetitions"] == 23, "Undefined paired input")
    mean, sd = summary["mean"], summary["sd"]
    se = sd/math.sqrt(23)
    half = float(t.ppf(.975, 22))*se
    p = float(2*t.sf(abs(mean/se), 22)) if se else (1.0 if mean == 0 else None)
    return dict(n=23, mean=mean, sd=sd, ci95_pointwise=[mean-half, mean+half],
                p_raw=p, t_test_defined=bool(se), values_by_seed=dict(zip(map(str, SEEDS), values)))


def holm(values):
    normalized = [1.0 if p is None else p for p in values]
    require(all(math.isfinite(p) and 0 <= p <= 1 for p in normalized), "Invalid probability")
    out, maximum = [None]*len(values), 0.0
    for position, index in enumerate(sorted(range(len(values)), key=lambda i: (normalized[i], i))):
        maximum = max(maximum, normalized[index]*(len(values)-position))
        out[index] = min(1.0, maximum) if values[index] is not None else None
    return out


def summary_fields(fields):
    return tuple(f"{f}_{suffix}" for f in fields for suffix in ("mean", "sd", "defined_repetitions"))


def compare_pair(row, expected, checks, label, inferential=False):
    checks.equal(integer(row["n"]), 23, label+":n")
    for key in ("mean", "sd"):
        checks.number(row[key], expected[key], label+":"+key)
    if expected["ci95_pointwise"] is None:
        require(row["ci95_pointwise"] == "" and row["values_by_seed"] == "", "Undefined pair must retain blanks")
    else:
        ci, values = literal(row["ci95_pointwise"]), literal(row["values_by_seed"])
        require(type(ci) is list and len(ci) == 2 and type(values) is dict and list(values) == list(map(str, SEEDS)), "Wrong paired endpoints/seed order")
        for observed, reference in zip(ci, expected["ci95_pointwise"]):
            require(type(observed) in (int, float), "Numeric interval endpoint required")
            checks.number(str(observed), reference, label+":ci")
        for seed in map(str, SEEDS):
            require(type(values[seed]) in (int, float), "Numeric paired value required")
            checks.number(str(values[seed]), expected["values_by_seed"][seed], label+":paired_value")
    if inferential:
        checks.number(row["p_raw"], expected["p_raw"], label+":p_raw")
        checks.equal(literal(row["t_test_defined"]), expected["t_test_defined"], label+":test_defined")


def verify_cells(rows, ids, expected, supports, checks, label, nullable=False, extras=False):
    index = keyed(rows, ids, expected, label)
    scores = {}
    for key, row in index.items():
        counts = [integer(row[f]) for f in ("tn", "fp", "fn", "tp")]
        calculated = metrics(*counts, nullable=nullable, extras=extras)
        n0, n1 = supports(key)
        checks.equal(counts[0]+counts[1], n0, label+":negative_support")
        checks.equal(counts[2]+counts[3], n1, label+":positive_support")
        for field, value in calculated.items():
            if field not in row:
                continue
            if type(value) is int:
                checks.equal(integer(row[field]), value, label+":"+field)
            else:
                checks.number(row[field], value, label+":"+field)
        scores[key] = calculated
    return scores


def verify_summaries(rows, ids, expected, scores, score_keys, fields, checks, label, nested=False):
    index = keyed(rows, ids, expected, label)
    for key, row in index.items():
        checks.equal(integer(row["repetitions"]), 23, label+":repetitions")
        block = [scores[k] for k in score_keys(key)]
        for field in fields:
            summary = mean_sd([r[field] for r in block])
            if nested:
                actual = literal(row[field])
                require(type(actual) is dict and list(actual) == ["mean", "sd", "defined_repetitions"], "Exact summary object schema differs")
                for suffix, value in summary.items():
                    if value is None:
                        checks.equal(actual[suffix], None, label+":undefined")
                    elif suffix == "defined_repetitions":
                        checks.equal(actual[suffix], value, label+":defined_repetitions")
                    else:
                        require(type(actual[suffix]) in (int, float), "Numeric summary required")
                        checks.number(str(actual[suffix]), value, label+":"+suffix)
            else:
                for suffix, value in summary.items():
                    if suffix == "defined_repetitions":
                        checks.equal(integer(row[field+"_"+suffix]), value, label+":defined_repetitions")
                    else:
                        checks.number(row[field+"_"+suffix], value, label+":"+suffix)


def exact_macro(row):
    return Fraction(row["macro_f1_numerator"], row["macro_f1_denominator"])


def verify_contrasts(rows, ids, expected, scores, keys_for, checks, label, primary=False, family_size=None, flag="primary"):
    expected = list(expected)
    index = keyed(rows, ids, expected, label)
    references, keys = [], []
    for identity in expected:
        key = tuple(map(str, identity)); row = index[key]
        left, right = keys_for(key)
        values = [float(exact_macro(scores[a])-exact_macro(scores[b])) for a, b in zip(left, right)]
        report = paired(values)
        require(row["metric"] == "macro_f1" and literal(row[flag]) is primary, "Wrong contrast role")
        compare_pair(row, report, checks, label, inferential=primary)
        references.append(report["p_raw"]);keys.append(key)
    if primary:
        require(len(keys) == family_size, "Wrong multiplicity family size")
        for key, adjusted in zip(keys, holm(references)):
            checks.number(index[key][f"p_holm_{family_size}"], adjusted, label+f":p_holm_{family_size}")
            if "Holm_slot_used" in index[key]:
                checks.equal(literal(index[key]["Holm_slot_used"]), True, label+":Holm_slot")


def verify_group_pairs(rows, ids, expected, group_scores, group_support, keys_for, checks, label, undefined_reason):
    index = keyed(rows, ids, expected, label);undefined = 0
    for key, row in index.items():
        left, right, count, denominator = keys_for(key)
        checks.equal(integer(row["denominator"]), denominator, label+":denominator")
        checks.equal(literal(row["metric_defined"]), bool(denominator), label+":defined")
        checks.equal(literal(row["confirmatory"]), False, label+":descriptive")
        if denominator:
            report = paired([float(Fraction(group_scores[a][count]-group_scores[b][count], denominator)) for a,b in zip(left,right)])
            if "undefined_reason" in row:
                checks.equal(row["undefined_reason"], "", label+":reason")
        else:
            undefined += 1
            report = dict(mean=None, sd=None, ci95_pointwise=None, values_by_seed=None)
            checks.equal(row["undefined_reason"], undefined_reason, label+":reason")
        compare_pair(row, report, checks, label)
    return undefined


def verify_subsets(groups, overall, keyselector, checks):
    # Each declared subgroup must be contained in its matching full cell.
    # Overlapping groups are checked individually, never summed.
    for key, group in groups.items():
        parent_key = keyselector(key)
        require(parent_key in overall, "Missing containing cell for subgroup")
        parent = overall[parent_key]
        for field in ("tn", "fp", "fn", "tp", "n"):
            require(type(group[field]) is int and type(parent[field]) is int,
                    "Integer subgroup and containing-cell counts required")
            checks.equal(0 <= group[field] <= parent[field], True, "subset:" + field)


def verify_partitions(scores, groups, group_keys, partition_names, checks):
    for key, overall in scores.items():
        for dimension in partition_names:
            members = [groups[k] for k in group_keys(key, dimension)]
            for field in ("tn","fp","fn","tp","n"):
                checks.equal(sum(r[field] for r in members), overall[field], "partition:"+field)


def control_keys(paths=PATHS):
    return [(p,m,s,a) for p in paths for s in SEEDS for m in MODELS for a in CONTROL_ARMS]


def contrast_keys(key):
    p,m,contrast=key;left,right=contrast.split("-")
    return ([(p,m,str(s),left) for s in SEEDS],[(p,m,str(s),right) for s in SEEDS])


def verify_control_tables(load, checks, corpus, nested=False):
    extras=nested
    fields=("tn","fp","fn","tp",*METRICS)
    cell_schema=ID_FIELDS+(NULLABLE_CELL_FIELDS if extras else CELL_FIELDS)
    scores=verify_cells(load("cells.csv",cell_schema),ID_FIELDS,control_keys(),lambda k:POPULATIONS[corpus],
                        checks,"cells",nullable=nested,extras=extras)
    summary_fields_used=("tn","fp","fn","tp","n","negative_reference_n","positive_reference_n","errors",*METRICS,*EXTRA_METRICS,"error_rate") if nested else fields
    summary_schema=("path","model","arm","repetitions")+(summary_fields_used if nested else summary_fields(fields))
    verify_summaries(load("arm_summaries.csv",summary_schema),("path","model","arm"),grid(PATHS,MODELS,CONTROL_ARMS),
                     scores,lambda k:[(k[0],k[1],str(s),k[2]) for s in SEEDS],summary_fields_used,checks,"arm_summary",nested)
    pair_schema=("path","model","contrast","metric","primary",*PAIR_FIELDS)
    primary_schema=pair_schema+("p_raw","t_test_defined","values_by_seed","p_holm_8")
    verify_contrasts(load("primary.csv",primary_schema),("path","model","contrast"),grid(PATHS,MODELS,("L-W","L-P")),
                     scores,contrast_keys,checks,"primary",True,8)
    verify_contrasts(load("S_references_descriptive.csv",pair_schema+("values_by_seed",)),("path","model","contrast"),
                     grid(PATHS,MODELS,("L-S","W-S","P-S")),scores,contrast_keys,checks,"S_reference")
    return scores


def verify_kold(load, checks):
    scores=verify_control_tables(load,checks,"KOLD")
    fields=("tn","fp","fn","tp",*METRICS)
    group_ids=ID_FIELDS+("dimension","value")
    expected=[(*k,d,v) for d,v in KOLD_GROUPS for k in control_keys()]
    raw=load("strata_cells.csv",group_ids+("negative_reference_n","positive_reference_n",*CELL_FIELDS,"errors","error_rate"))
    groups=verify_cells(raw,
                        group_ids,expected,lambda k:KOLD_GROUPS[k[-2:]],checks,"stratum",nullable=True)
    verify_subsets(groups, scores, lambda k: k[:4], checks)
    for key,row in groups.items():
        # These quantities are reconstructed from the counts even though they
        # are outside the base metric dictionary.
        row.update(errors=row["fp"]+row["fn"],error_rate=(row["fp"]+row["fn"])/row["n"])
    # Explicitly verify the auxiliary columns, rather than treating them as
    # unchecked display metadata.
    for row in raw:
        key=tuple(row[c] for c in group_ids); n0,n1=KOLD_GROUPS[key[-2:]]
        checks.equal(integer(row["negative_reference_n"]),n0,"stratum:negative_reference_n")
        checks.equal(integer(row["positive_reference_n"]),n1,"stratum:positive_reference_n")
        checks.equal(integer(row["errors"]),groups[key]["errors"],"stratum:errors")
        checks.number(row["error_rate"],groups[key]["error_rate"],"stratum:error_rate")
    ids=("dimension","value","path","model","arm")
    summary_schema=("dimension","value","n","negative_reference_n","positive_reference_n","path","model","arm","repetitions",*summary_fields(fields))
    summaries=load("strata_summaries.csv",summary_schema)
    verify_summaries(summaries,ids,[(*g,p,m,a) for g in KOLD_GROUPS for p,m,a in grid(PATHS,MODELS,CONTROL_ARMS)],groups,
                     lambda k:[(k[2],k[3],str(s),k[4],k[0],k[1]) for s in SEEDS],fields,checks,"stratum_summary")
    for row in summaries:
        n0,n1=KOLD_GROUPS[row["dimension"],row["value"]]
        for f,n in (("n",n0+n1),("negative_reference_n",n0),("positive_reference_n",n1)):
            checks.equal(integer(row[f]),n,"stratum_summary:"+f)
    pair_ids=("path","model","contrast","dimension","value","metric")
    pair_schema=pair_ids+("denominator","metric_defined","confirmatory",*PAIR_FIELDS,"values_by_seed","undefined_reason")
    expected=[(p,m,c,d,v,metric) for d,v in KOLD_GROUPS for p,m,c,metric in grid(PATHS,MODELS,("L-S","L-W","L-P"),("hate_recall","false_positive_rate"))]
    def keys(k):
        p,m,c,d,v,metric=k;right=c.split("-")[1]; count="tp" if metric=="hate_recall" else "fp";denominator=KOLD_GROUPS[d,v][1 if count=="tp" else 0]
        return [(p,m,str(s),"L",d,v) for s in SEEDS],[(p,m,str(s),right,d,v) for s in SEEDS],count,denominator
    undefined=verify_group_pairs(load("strata_contrasts_descriptive.csv",pair_schema),pair_ids,expected,groups,KOLD_GROUPS,keys,
                                 checks,"stratum_contrast","No reference-class support in this native stratum.")
    checks.equal(undefined,432,"undefined_stratum_slots")
    verify_partitions(scores,groups,lambda k,d:[(*k,*g) for g in KOLD_GROUPS if g[0]==d],("source","OFF_TGT"),checks)
    internal=verify_cells(load("internal_EXAONE_cells.csv",ID_FIELDS+CELL_FIELDS),ID_FIELDS,control_keys(("exaone",)),
                          lambda k:POPULATIONS["KHATERS"],checks,"internal_cell")
    verify_summaries(load("internal_EXAONE_arm_summaries.csv",("path","model","arm","repetitions",*summary_fields(fields))),
                     ("path","model","arm"),grid(("exaone",),MODELS,CONTROL_ARMS),internal,
                     lambda k:[(k[0],k[1],str(s),k[2]) for s in SEEDS],fields,checks,"internal_summary")
    pair_schema=("path","model","contrast","metric","confirmatory",*PAIR_FIELDS,"values_by_seed")
    for name, contrasts in (("internal_EXAONE_L_W_L_P_descriptive.csv",("L-W","L-P")),("internal_EXAONE_S_references_descriptive.csv",("L-S","W-S","P-S"))):
        verify_contrasts(load(name,pair_schema),("path","model","contrast"),grid(("exaone",),MODELS,contrasts),internal,
                         contrast_keys,checks,"internal_descriptive",flag="confirmatory")
    return dict(cells=368,arm_summaries=16,primary=8,S_references=12,strata=38,strata_cells=13984,
                strata_summaries=608,strata_contrasts=912,undefined_stratum_slots=undefined,
                internal_cells=184,internal_arm_summaries=8,internal_descriptive=10,new_internal_pvalues=0)


def verify_apeach(load,checks):
    scores=verify_control_tables(load,checks,"APEACH",nested=True)
    topic="writer_prompt_topic_original";ids=ID_FIELDS+(topic,)
    groups=verify_cells(load("writer_topic_cells.csv",ids+NULLABLE_CELL_FIELDS),ids,
                        [(*k,t) for t in TOPICS for k in control_keys()],lambda k:TOPICS[k[-1]],checks,"topic_cell",True,True)
    verify_subsets(groups, scores, lambda k: k[:4], checks)
    fields=("tn","fp","fn","tp","n","negative_reference_n","positive_reference_n","errors",*METRICS,*EXTRA_METRICS,"error_rate")
    summary_schema=(topic,"path","model","arm","repetitions",*fields)
    verify_summaries(load("writer_topic_summaries.csv",summary_schema),(topic,"path","model","arm"),
                     [(t,p,m,a) for t in TOPICS for p,m,a in grid(PATHS,MODELS,CONTROL_ARMS)],groups,
                     lambda k:[(k[1],k[2],str(s),k[3],k[0]) for s in SEEDS],fields,checks,"topic_summary",True)
    pair_ids=("path","model","contrast",topic,"metric")
    pair_schema=pair_ids+("denominator","metric_defined","confirmatory",*PAIR_FIELDS,"values_by_seed")
    expected=[(p,m,c,t,metric) for t in TOPICS for p,m,c,metric in grid(PATHS,MODELS,("L-S","L-W","L-P"),("positive_reference_recall","negative_reference_false_positive_rate"))]
    def keys(k):
        p,m,c,t,metric=k;count="tp" if metric=="positive_reference_recall" else "fp"
        return [(p,m,str(s),"L",t) for s in SEEDS],[(p,m,str(s),c.split("-")[1],t) for s in SEEDS],count,TOPICS[t][1 if count=="tp" else 0]
    verify_group_pairs(load("writer_topic_contrasts_descriptive.csv",pair_schema),pair_ids,expected,groups,TOPICS,keys,checks,"topic_contrast","")
    verify_partitions(scores,groups,lambda k,d:[(*k,t) for t in TOPICS],("topics",),checks)
    return dict(cells=368,arm_summaries=16,primary=8,S_references=12,topics=10,topic_cells=3680,topic_summaries=160,topic_contrasts=240)


def policy_groups(corpus):
    if corpus=="KOLD":
        return KOLD_GROUPS
    if corpus=="KHATERS":
        return {("target_positive",t):(0,n) for t,n in zip(TARGETS,TARGET_SUPPORT)}
    return {("writer_prompt_topic",t):n for t,n in TOPICS.items()}


def verify_policy(load,checks):
    ids=("corpus",*ID_FIELDS)
    expected=list(grid(CORPORA,PATHS,MODELS,SEEDS,POLICY_ARMS))
    scores=verify_cells(load("cells.csv",ids+NULLABLE_CELL_FIELDS),ids,expected,lambda k:POPULATIONS[k[0]],checks,"policy_cell",True,True)
    fields=("tn","fp","fn","tp",*METRICS,*EXTRA_METRICS,"errors","error_rate")
    schema=("corpus","path","model","arm","repetitions","n","negative_reference_n","positive_reference_n",*summary_fields(fields))
    summaries=load("arm_summaries.csv",schema)
    verify_summaries(summaries,("corpus","path","model","arm"),grid(CORPORA,PATHS,MODELS,POLICY_ARMS),scores,
                     lambda k:[(k[0],k[1],k[2],str(s),k[3]) for s in SEEDS],fields,checks,"policy_summary")
    for row in summaries:
        n0,n1=POPULATIONS[row["corpus"]]
        for f,n in (("n",n0+n1),("negative_reference_n",n0),("positive_reference_n",n1)):
            checks.equal(integer(row[f]),n,"policy_summary:"+f)
    pids=("corpus","path","model","contrast")
    schema=pids+("metric","primary",*PAIR_FIELDS,"p_raw","t_test_defined","values_by_seed","p_holm_12","Holm_slot_used")
    verify_contrasts(load("primary.csv",schema),pids,grid(CORPORA,PATHS,MODELS,("B-A",)),scores,
                     lambda k:([(k[0],k[1],k[2],str(s),"B") for s in SEEDS],[(k[0],k[1],k[2],str(s),"A") for s in SEEDS]),
                     checks,"policy_primary",True,12)
    gids=ids+("dimension","value")
    expected=[(c,p,m,s,a,d,v) for c in CORPORA for d,v in policy_groups(c) for s,p,m,a in grid(SEEDS,PATHS,MODELS,POLICY_ARMS)]
    groups=verify_cells(load("strata_cells.csv",gids+NULLABLE_CELL_FIELDS),gids,expected,
                        lambda k:policy_groups(k[0])[k[-2:]],checks,"policy_stratum",True,True)
    verify_subsets(groups, scores, lambda k: k[:5], checks)
    sids=("corpus","path","model","arm","dimension","value")
    schema=sids+("n","negative_reference_n","positive_reference_n","repetitions",*summary_fields(fields))
    summaries=load("strata_summaries.csv",schema)
    expected=[(c,p,m,a,d,v) for c in CORPORA for d,v in policy_groups(c) for p,m,a in grid(PATHS,MODELS,POLICY_ARMS)]
    verify_summaries(summaries,sids,expected,groups,lambda k:[(k[0],k[1],k[2],str(s),k[3],k[4],k[5]) for s in SEEDS],fields,checks,"policy_stratum_summary")
    for row in summaries:
        n0,n1=policy_groups(row["corpus"])[row["dimension"],row["value"]]
        for f,n in (("n",n0+n1),("negative_reference_n",n0),("positive_reference_n",n1)):
            checks.equal(integer(row[f]),n,"policy_stratum_summary:"+f)
    pids=("corpus","path","model","dimension","value","metric","contrast")
    schema=pids+("confirmatory","metric_defined","denominator",*PAIR_FIELDS,"values_by_seed","undefined_reason")
    expected=[(c,p,m,d,v,metric,"B-A") for c in CORPORA for d,v in policy_groups(c) for p,m,metric in grid(PATHS,MODELS,("hate_recall","false_positive_rate","error_rate"))]
    def keys(k):
        c,p,m,d,v,metric,_=k;n0,n1=policy_groups(c)[d,v];count={"hate_recall":"tp","false_positive_rate":"fp","error_rate":"errors"}[metric]
        return [(c,p,m,str(s),"B",d,v) for s in SEEDS],[(c,p,m,str(s),"A",d,v) for s in SEEDS],count,{"tp":n1,"fp":n0,"errors":n0+n1}[count]
    undefined=verify_group_pairs(load("strata_contrasts_descriptive.csv",schema),pids,expected,groups,None,keys,checks,"policy_stratum_contrast","No reference-class support in this fixed stratum.")
    checks.equal(undefined,172,"policy_undefined_slots")
    for c,partitions in (("KOLD",("source","OFF_TGT")),("APEACH",("writer_prompt_topic",))):
        verify_partitions({k:v for k,v in scores.items() if k[0]==c},groups,
                          lambda k,d:[(*k,*g) for g in policy_groups(c) if g[0]==d],partitions,checks)
    aux=verify_policy_diagnostics(load,checks)
    return dict(cells=552,arm_summaries=24,primary=12,strata=55,strata_cells=10120,
                strata_summaries=440,strata_contrasts=660,undefined_stratum_slots=undefined,**aux)



def verify_policy_diagnostics(load,checks):
    sources=("curatedhs","metahate");classes=("non-hate","hate")
    ab_fields=tuple(f"A_{a}__B_{b}" for a,b in grid(classes,classes))
    summary_ids=("path","source_corpus","inherited_source_class","denominator_basis")
    schema=summary_ids+("n","unique_ID_n","occurrence_n",*ab_fields,"changed_n","changed_rate")
    summary=keyed(load("annotation_turnover_summary.csv",schema),summary_ids,
                  grid(PATHS,sources,classes,("unique_source_ID","training_row_occurrence")),"turnover_summary")
    repetition_ids=("path","repeat_seed","source_corpus","inherited_source_class")
    reps=keyed(load("annotation_turnover_by_repetition.csv",repetition_ids+("n",*ab_fields)),repetition_ids,
               [(p,str(s),source,c) for p in PATHS for source in sources for c in classes for s in SEEDS],"turnover_repetition")
    for key,row in reps.items():
        counts=[integer(row[f]) for f in ab_fields]
        checks.equal(sum(counts),integer(row["n"]),"turnover:partition")
    for key,row in summary.items():
        path,source,source_class,basis=key
        n,unique,occurrences=[integer(row[f]) for f in ("n","unique_ID_n","occurrence_n")]
        counts=[integer(row[f]) for f in ab_fields]
        checks.equal(sum(counts),n,"turnover:partition")
        require(unique<=occurrences<=23*unique,"Invalid occurrence/unique denominator relation")
        checks.equal(n,unique if basis=="unique_source_ID" else occurrences,"turnover:denominator_basis")
        checks.equal(integer(row["changed_n"]),counts[1]+counts[2],"turnover:changed_n")
        checks.number(row["changed_rate"],(counts[1]+counts[2])/n if n else None,"turnover:changed_rate")
        other=summary[path,source,source_class,"training_row_occurrence" if basis=="unique_source_ID" else "unique_source_ID"]
        for f in ("unique_ID_n","occurrence_n"):
            checks.equal(integer(row[f]),integer(other[f]),"turnover:shared_support")
        block=[reps[path,str(s),source,source_class] for s in SEEDS]
        if basis=="training_row_occurrence":
            for f in ("n",*ab_fields):
                checks.equal(integer(row[f]),sum(integer(r[f]) for r in block),"turnover:repeat_sum")
        else:
            for f in ab_fields:
                u,occ=integer(row[f]),integer(other[f])
                require(u<=occ<=23*u,"Unique/category occurrence counts differ")
    for p,total in (("exaone",23615),("gemma4",23633)):
        checks.equal(sum(integer(r["n"]) for k,r in summary.items() if k[0]==p and k[-1]=="unique_source_ID"),total,"turnover:unique_population")
    cell_ids=("path","arm")
    rows=load("native2000_diagnostic_cells.csv",cell_ids+NULLABLE_CELL_FIELDS+("new_independent_semantic_validation",))
    native=verify_cells(rows,cell_ids,grid(PATHS,POLICY_ARMS),lambda k:(1000,1000),checks,"native_cell",True,True)
    for row in rows:
        checks.equal(literal(row["new_independent_semantic_validation"]),False,"native:reused_reference")
    tids=("path","human_reference_class")
    binary_fields=tuple(f"A_{a}__B_{b}" for a,b in grid((0,1),(0,1)))
    tail=("both_correct","recovered_under_B","new_errors_under_B","both_wrong")
    transitions=keyed(load("native2000_diagnostic_binary_transitions_by_reference_class.csv",tids+("n",*binary_fields,*tail)),tids,
                      grid(PATHS,(0,1)),"native_transition")
    for key,row in transitions.items():
        c=int(key[-1]);values={(a,b):integer(row[f"A_{a}__B_{b}"]) for a,b in grid((0,1),(0,1))}
        checks.equal(integer(row["n"]),1000,"native_transition:n")
        checks.equal(sum(values.values()),1000,"native_transition:sum")
        for field,count in zip(tail,(values[c,c],values[1-c,c],values[c,1-c],values[1-c,1-c])):
            checks.equal(integer(row[field]),count,"native_transition:"+field)
    for path,arm in grid(PATHS,POLICY_ARMS):
        truth0=transitions[path,"0"];truth1=transitions[path,"1"]
        margin=lambda row,v:sum(integer(row[f"A_{a}__B_{b}"]) for a,b in grid((0,1),(0,1)) if (a if arm=="A" else b)==v)
        for field,value in (("tn",margin(truth0,0)),("fp",margin(truth0,1)),("fn",margin(truth1,0)),("tp",margin(truth1,1))):
            checks.equal(native[path,arm][field],value,"native_transition:cell_margin")
    fields=TARGETS+("individual","unspecified_group","insult","swear_words","obscenity","threat")
    domains={f:((0,1) if f in ("individual","unspecified_group") else (0,1,2)) for f in fields}
    dids=("path","arm","human_reference_class","field","score_value")
    dschema=dids+("n","count","rate")
    expected=[(p,a,c,f,v) for p,a in grid(PATHS,POLICY_ARMS) for c in (0,1) for f in fields for v in domains[f]]
    distributions=keyed(load("native2000_diagnostic_all13_score_distributions.csv",dschema),dids,expected,"native_score_distribution")
    for key,row in distributions.items():
        checks.equal(integer(row["n"]),1000,"native_score:n")
        count=integer(row["count"]);require(count<=1000,"Native score count exceeds reference support")
        checks.number(row["rate"],count/1000,"native_score:rate")
    for p,a,c,f in grid(PATHS,POLICY_ARMS,(0,1),fields):
        checks.equal(sum(integer(distributions[p,a,str(c),f,str(v)]["count"]) for v in domains[f]),1000,"native_score:partition")
    pids=("path","arm","human_reference_class","teacher_predicted_target")
    pschema=pids+("n","predicted_presence_count","predicted_presence_rate","human_target_reference_available")
    presence=keyed(load("native2000_diagnostic_teacher_target_presence.csv",pschema),pids,
                   [(p,a,c,t) for p,a in grid(PATHS,POLICY_ARMS) for c in (0,1) for t in TARGETS],"native_target_presence")
    for key,row in presence.items():
        p,a,c,t=key;count=sum(integer(distributions[p,a,c,t,str(v)]["count"]) for v in (1,2))
        checks.equal(integer(row["n"]),1000,"native_presence:n")
        checks.equal(integer(row["predicted_presence_count"]),count,"native_presence:count")
        checks.number(row["predicted_presence_rate"],count/1000,"native_presence:rate")
        checks.equal(literal(row["human_target_reference_available"]),False,"native_presence:no_target_reference")
    for p,a,c in grid(PATHS,POLICY_ARMS,(0,1)):
        supports=[integer(presence[p,a,str(c),t]["predicted_presence_count"]) for t in TARGETS]
        union=native[p,a]["tp" if c else "fp"]
        require(max(supports)<=union<=min(1000,sum(supports)),"Target-score and binary margins cannot agree")
    return dict(annotation_turnover_summaries=16,annotation_turnover_by_repetition=184,
                native_cells=4,native_transitions=4,native_score_distributions=296,native_target_presence=56,
                private_unique_item_map_checked=False)

def run(family, data, output=None):
    require(family in FILES, "Unknown family identity")
    folder=Path(data)
    require(folder.is_dir() and not folder.is_symlink(), "Regular aggregate directory required")
    require({p.name for p in folder.iterdir() if p.suffix.lower()==".csv"} == set(FILES[family]), "Exact aggregate CSV membership differs")
    require(not any(p.is_symlink() for p in folder.iterdir()), "Symbolic aggregate member")
    checks, descriptors = Checks(), []
    def load(name, schema):
        rows, item=table(folder,name,schema);descriptors.append(item);return rows
    if family == "KOLD":
        counts = verify_kold(load, checks)
    elif family == "APEACH":
        counts = verify_apeach(load, checks)
    else:
        counts = verify_policy(load, checks)
    require({x["path"] for x in descriptors}==set(FILES[family]), "A declared aggregate was not checked")
    require({p.name for p in folder.iterdir() if p.suffix.lower()==".csv"} == set(FILES[family]), "Aggregate membership changed during check")
    for item in descriptors:
        member=folder/item["path"]
        require(member.is_file() and not member.is_symlink(), "Aggregate input changed during check")
        final_bytes=member.read_bytes()
        require(len(final_bytes)==item["bytes"] and hashlib.sha256(final_bytes).hexdigest()==item["sha256"],
                "Aggregate input changed during check")
    result=dict(status="PASS", family=FAMILY_IDS[family], family_identity=family,
                input_files=sorted(descriptors,key=lambda x:x["path"]), checked_rows=counts,
                checks=dict(checks.counts),maximum_numeric_difference=dict(checks.max_difference),
                scope="Aggregate arithmetic only; unreleased item alignment and result provenance require separate review.")
    if output is not None:
        target=Path(output)
        require(target.resolve()!=folder.resolve() and folder.resolve() not in target.resolve().parents, "Output must be outside input directory")
        require(not target.exists(), "Preserve existing verification output")
        target.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family",required=True,choices=tuple(FILES))
    parser.add_argument("--data",required=True,type=Path)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    result=run(args.family,args.data,args.output)
    print(json.dumps({k:result[k] for k in ("status","family_identity","checked_rows")},indent=2))


if __name__=="__main__":
    main()

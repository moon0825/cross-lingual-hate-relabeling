#!/usr/bin/env python3
"""Recompute the Gemma control tables from released aggregate integer counts.

Requires scipy for Student-t probabilities. No manuscript package, author
statistics helper, model, prediction row, source text or individual response is
loaded. The arithmetic checks released counts, not their private assignments.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import itertools
import json
import math
from pathlib import Path

MODELS = ("kcelectra", "xlmr")
SEEDS = tuple(range(20260901, 20260924))
ARMS = ("S", "L", "W", "P")
TARGETS = ("gender", "age", "race_or_region_of_origin", "religion",
           "politics", "occupation", "disability")
METRICS = ("macro_f1", "mcc", "balanced_accuracy", "non_hate_recall",
           "hate_recall", "predicted_hate_rate")
FILES = {
    "cell_scores": "gemma_cell_scores.csv",
    "target_recalls": "gemma_target_recall_by_repeat.csv",
    "macro_contrasts": "gemma_macro_contrasts4.csv",
    "target_contrasts": "gemma_target_contrasts14.csv",
    "descriptive_contrasts": "gemma_descriptive_contrasts6.csv",
    "arm_summary": "gemma_arm_summary8.csv",
}
PAIR_FIELDS = ("n", "mean", "sd", "ci95_low", "ci95_high")
SCHEMAS = {
    "cell_scores": ("model", "repeat_seed", "arm", "tn", "fp", "fn", "tp", *METRICS),
    "target_recalls": ("model", "repeat_seed", "arm", "target", "hate_n", "tp", "recall"),
    "macro_contrasts": ("model", "metric", "contrast", "primary", *PAIR_FIELDS,
                        "p_raw", "t_test_defined", "p_holm_4"),
    "target_contrasts": ("model", "metric", "target", "contrast", *PAIR_FIELDS,
                         "p_raw", "t_test_defined", "p_holm_14"),
    "descriptive_contrasts": ("model", "contrast", "primary", *PAIR_FIELDS),
    "arm_summary": ("model", "arm", "n", *(f"{m}_{s}" for m in METRICS for s in ("mean", "sd"))),
}
N_EVAL, N_HATE, N_NON_HATE = 9997, 3198, 6799


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.maximum_difference = defaultdict(float)

    def equal(self, value, expected, category, key):
        if value != expected:
            raise ValueError(f"{category} differs at {key}: {value!r} != {expected!r}")
        self.counts[category] += 1

    def number(self, value, expected, category, key):
        if expected is None:
            self.equal(value, "", category + "_undefined_blank", key)
            return
        try:
            observed = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid {category} at {key}") from exc
        difference = abs(observed - expected)
        tolerance = max(2e-12, 4 * math.ulp(float(expected)))
        if "probability" in category or "holm" in category:
            # Preserve tiny positive probabilities; do not accept zero merely
            # because an absolute score tolerance is larger than the p value.
            tolerance = max(1e-300, abs(expected) * 1e-8, 8 * math.ulp(float(expected)))
        if not math.isfinite(observed) or difference > tolerance:
            raise ValueError(f"{category} differs at {key} by {difference}")
        self.counts[category] += 1
        self.maximum_difference[category] = max(self.maximum_difference[category], difference)


def integer(value):
    if not isinstance(value, str) or not value.isdigit():
        raise ValueError(f"Non-negative integer required: {value!r}")
    return int(value)


def table(path, columns):
    if not path.is_file() or path.is_symlink():
        raise ValueError("Missing or symbolic Gemma aggregate CSV")
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if tuple(reader.fieldnames or ()) != columns:
            raise ValueError(f"Exact public CSV column schema differs: {path.name}")
        rows = list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError(f"Malformed CSV row: {path.name}")
    return rows


def grid(*dimensions):
    return {tuple(map(str, values)) for values in itertools.product(*dimensions)}


def keyed(rows, columns, expected, name, checks):
    result = {}
    for row in rows:
        key = tuple(row[c] for c in columns)
        if key in result:
            raise ValueError(f"Duplicate {name} identity: {key}")
        result[key] = row
    checks.equal(set(result), expected, name + "_exact_grid", name)
    return result


def macro_f1_fraction(tn, fp, fn, tp):
    """Keep the binary macro average exact until a point/difference is emitted."""
    if any(type(value) is not int or value < 0 for value in (tn, fp, fn, tp)):
        raise ValueError("Macro-F1 requires non-negative integer confusion counts")
    positive, negative = 2 * tp + fp + fn, 2 * tn + fp + fn
    return ((Fraction(tp, positive) if positive else Fraction(0)) +
            (Fraction(tn, negative) if negative else Fraction(0)))


def binary_metrics(tn, fp, fn, tp):
    mcc_denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    hate_recall, non_recall = tp / (tp + fn), tn / (tn + fp)
    return {"macro_f1": float(macro_f1_fraction(tn, fp, fn, tp)),
            "mcc": (tp * tn - fp * fn) / mcc_denom if mcc_denom else 0.0,
            "balanced_accuracy": (hate_recall + non_recall) / 2,
            "non_hate_recall": non_recall, "hate_recall": hate_recall,
            "predicted_hate_rate": (tp + fp) / (tn + fp + fn + tp)}


def mean_sd(values):
    n = len(values)
    mean = math.fsum(values) / n
    sd = math.sqrt(math.fsum((x - mean) ** 2 for x in values) / (n - 1))
    if len(set(values)) == 1:
        sd = 0.0
    return mean, sd


def paired_values(values):
    from scipy.stats import t
    if len(values) != 23 or not all(math.isfinite(v) for v in values):
        raise ValueError("Exactly23 finite paired differences required")
    mean, sd = mean_sd(values)
    se = sd / math.sqrt(23)
    half = float(t.ppf(.975, 22)) * se
    # Zero mean/variance retains p=1; nonzero constant differences have no
    # estimated-variance t probability and retain a blank adjusted probability.
    p = float(2 * t.sf(abs(mean / se), 22)) if se else (1.0 if mean == 0 else None)
    return {"n": 23, "mean": mean, "sd": sd,
            "ci95_low": mean - half, "ci95_high": mean + half,
            "p_raw": p, "t_test_defined": bool(se)}


def holm(values):
    if any(v is not None and (not math.isfinite(v) or not 0 <= v <= 1) for v in values):
        raise ValueError("Invalid raw probability")
    normalized = [1.0 if v is None else v for v in values]
    order = sorted(range(len(values)), key=lambda i: (normalized[i], i))
    output, maximum = [None] * len(values), 0.0
    for position, index in enumerate(order):
        maximum = max(maximum, normalized[index] * (len(values) - position))
        output[index] = min(1.0, maximum) if values[index] is not None else None
    return output


def run(root, output=None):
    root = Path(root).resolve()
    data = root / "data/gemma_20261010"
    actual_names = {p.name for p in data.iterdir()} if data.is_dir() else set()
    if actual_names != set(FILES.values()):
        raise ValueError("Gemma public directory must contain exactly the six declared CSV files")
    inputs = {role: table(data / filename, SCHEMAS[role]) for role, filename in FILES.items()}
    checks = Checks()
    cells = keyed(inputs["cell_scores"], ("model", "repeat_seed", "arm"), grid(MODELS, SEEDS, ARMS), "184cells", checks)
    recalls = keyed(inputs["target_recalls"], ("model", "repeat_seed", "arm", "target"),
                    grid(MODELS, SEEDS, ARMS, TARGETS), "1288target_recalls", checks)
    macros = keyed(inputs["macro_contrasts"], ("model", "contrast"), grid(MODELS, ("L-W", "L-P")), "4macro_family", checks)
    target_reports = keyed(inputs["target_contrasts"], ("model", "target", "contrast"),
                           grid(MODELS, TARGETS, ("L-W",)), "14target_family", checks)
    descriptive = keyed(inputs["descriptive_contrasts"], ("model", "contrast"),
                        grid(MODELS, ("L-S", "P-S", "W-S")), "6descriptive", checks)
    arms = keyed(inputs["arm_summary"], ("model", "arm"), grid(MODELS, ARMS), "8arm_summary", checks)
    reconstructed_metrics, exact_macro = {}, {}
    for key, row in cells.items():
        tn, fp, fn, tp = (integer(row[c]) for c in ("tn", "fp", "fn", "tp"))
        checks.equal(tn + fp + fn + tp, N_EVAL, "evaluation_population", key)
        checks.equal(tp + fn, N_HATE, "hate_population", key)
        checks.equal(tn + fp, N_NON_HATE, "nonhate_population", key)
        metrics = binary_metrics(tn, fp, fn, tp)
        reconstructed_metrics[key] = metrics
        exact_macro[key] = macro_f1_fraction(tn, fp, fn, tp)
        for metric, value in metrics.items():
            checks.number(row[metric], value, "integer_count_metric", key + (metric,))
    target_support, reconstructed_recalls, target_tp = {}, {}, {}
    for key, row in recalls.items():
        model, seed, arm, target = key
        n, tp = integer(row["hate_n"]), integer(row["tp"])
        if not 0 < n <= N_HATE or not 0 <= tp <= n:
            raise ValueError("Target support/true-positive bounds differ")
        target_support.setdefault(target, n)
        checks.equal(n, target_support[target], "fixed_target_support", key)
        checks.number(row["recall"], tp / n, "integer_target_recall", key)
        total_tp = integer(cells[model, seed, arm]["tp"])
        if tp > total_tp or (total_tp - tp) > (N_HATE - n):
            raise ValueError("Target true positives cannot be a subset of overall hate positives")
        reconstructed_recalls[key] = tp / n
        target_tp[key] = tp
    # Overlapping target strata must not be added as disjoint populations.
    primary_values = {}
    for model, right in itertools.product(MODELS, ("W", "P")):
        key = model, "L-" + right
        primary_values[key] = paired_values([
            float(exact_macro[model, str(seed), "L"] -
                  exact_macro[model, str(seed), right]) for seed in SEEDS])
    target_values = {}
    for model, target in itertools.product(MODELS, TARGETS):
        key = model, target, "L-W"
        target_values[key] = paired_values([
            float(Fraction(target_tp[model, str(seed), "L", target] -
                           target_tp[model, str(seed), "W", target], target_support[target])) for seed in SEEDS])

    def check_pair(row, expected, key, category, inferential):
        checks.equal(integer(row["n"]), 23, category + "_n", key)
        for field in PAIR_FIELDS[1:]:
            checks.number(row[field], expected[field], category + "_summary", key + (field,))
        if inferential:
            checks.number(row["p_raw"], expected["p_raw"], category + "_raw_probability", key)
            checks.equal(row["t_test_defined"], str(expected["t_test_defined"]), category + "_t_defined", key)

    for family, reported, adjusted_column, category in (
        (primary_values, macros, "p_holm_4", "macro_primary"),
        (target_values, target_reports, "p_holm_14", "positive_target"),
    ):
        corrected = holm([v["p_raw"] for v in family.values()])
        for (key, expected), adjusted in zip(family.items(), corrected):
            row = reported[key]
            checks.equal(row["metric"], "macro_f1" if category == "macro_primary" else "positive_target_recall",
                         category + "_metric", key)
            if category == "macro_primary":
                checks.equal(row["primary"], "True", "primary_flag", key)
            check_pair(row, expected, key, category, True)
            checks.number(row[adjusted_column], adjusted, category + "_separate_holm", key)
    for model, left in itertools.product(MODELS, ("L", "P", "W")):
        key = model, left + "-S"
        expected = paired_values([
            float(exact_macro[model, str(seed), left] -
                  exact_macro[model, str(seed), "S"]) for seed in SEEDS])
        checks.equal(descriptive[key]["primary"], "False", "descriptive_flag", key)
        check_pair(descriptive[key], expected, key, "descriptive", False)
    for model, arm in itertools.product(MODELS, ARMS):
        key = model, arm
        checks.equal(integer(arms[key]["n"]), 23, "arm_n", key)
        for metric in METRICS:
            values = [reconstructed_metrics[model, str(seed), arm][metric] for seed in SEEDS]
            mean, sd = mean_sd(values)
            checks.number(arms[key][metric + "_mean"], mean, "arm_mean", key + (metric,))
            checks.number(arms[key][metric + "_sd"], sd, "arm_sd", key + (metric,))
    paths = [data / filename for filename in FILES.values()]
    report = {"status": "PASS", "scope": "Gemma S/L/W/P aggregate counts on unchanged human evaluation; two classifiers,23matched repetitions.",
              "method": "Independent integer-count binary metrics; exact rational macro-F1 points/differences and target integer-TP differences before float conversion; paired23 t22 pointwise intervals and separate Holm4/Holm14 families; no author helper imported or epsilon rule.",
              "cell_rows": len(cells), "target_rows": len(recalls), "primary_rows": len(macros),
              "target_family_rows": len(target_reports), "descriptive_rows": len(descriptive), "arm_rows": len(arms),
              "target_support": target_support, "checks_by_category": dict(sorted(checks.counts.items())),
              "maximum_absolute_differences": dict(sorted(checks.maximum_difference.items())),
              "numeric_policy": "Integer counts exact; score summaries within max(2e-12,four ULPs); probabilities within max(1e-300,1e-8 relative,eight ULPs); undefined probabilities blank. Exact byte approval is checked separately by the private package gate.",
              "approved_export_sha256": {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              "limits": "Aggregate arithmetic cannot establish private row/target assignment or semantic label validity. Those are separate actual independent input/numeric reviews. No claim independent human confirmation.",
              "new_training_or_model_calls": 0}
    if output is not None:
        output = Path(output).resolve()
        if output == root or root in output.parents:
            raise ValueError("Verification output must be outside the companion")
        output.mkdir(parents=True, exist_ok=True)
        (output / "verification.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = run(args.root, args.output)
    print(json.dumps({k: report[k] for k in ("status", "cell_rows", "target_rows", "primary_rows", "target_family_rows", "descriptive_rows", "arm_rows")}, indent=2))


if __name__ == "__main__":
    main()

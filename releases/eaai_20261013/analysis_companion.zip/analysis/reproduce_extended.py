#!/usr/bin/env python3
"""Verify the complete local companion, historical results and CPU extension.

Requires the packages in requirements.txt for the historical statistical checks.
The added CPU checker uses only the Python standard library. No model downloads,
training, private prediction files or individual responses are needed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
CHECKSUM_FILE = "SHA256SUMS_REINFORCEMENT.txt"
sys.dont_write_bytecode = True


def verify_checksums():
    expected = {}
    for line in (ROOT / CHECKSUM_FILE).read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        path = Path(name)
        if (path.is_absolute() or ".." in path.parts or "\\" in name or ":" in name
                or path.as_posix() != name or name in expected):
            raise ValueError("Unsafe or duplicate checksum member")
        expected[name] = digest
    actual = {}
    for path in ROOT.rglob("*"):
        if path.is_symlink():
            raise ValueError("Companion symlink is not allowed")
        if path.is_file():
            name = path.relative_to(ROOT).as_posix()
            if name != CHECKSUM_FILE:
                actual[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError("Complete companion payload/checksum mismatch")
    return {"status": "PASS", "payload_files": len(actual), "checksum_file": CHECKSUM_FILE}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT.parent / "extended_reproduction_outputs_20261010")
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError("Choose an output directory outside the companion")
    checksum_report = verify_checksums()
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run([sys.executable, "-B", str(ROOT / "reproduce.py"),
                             "--output", str(output / "historical")],
                            cwd=ROOT.parent, env=env, capture_output=True, text=True, timeout=120)
    if result.returncode:
        raise RuntimeError("Historical numerical verification failed: " + result.stderr[-1000:])
    historical = json.loads((output / "historical/verification.json").read_text())
    if historical.get("status") != "PASS":
        raise ValueError("Historical numerical report is not PASS")
    from reproduce_cpu_20261010 import run
    cpu = run(ROOT, output / "cpu_20261010")
    if cpu.get("status") != "PASS":
        raise ValueError("CPU numerical report is not PASS")
    from reproduce_gemma_20261010 import run as check_gemma
    gemma = check_gemma(ROOT, output / "gemma_20261010")
    if gemma.get("status") != "PASS":
        raise ValueError("Gemma aggregate numeric report is not PASS")
    new_specs = {'kold_controls': {'cli': 'KOLD', 'family': 'new_KOLD_assignment_controls_8', 'directory': 'data/kold_controls_20261010', 'files': ('cells.csv', 'arm_summaries.csv', 'primary.csv', 'S_references_descriptive.csv', 'strata_cells.csv', 'strata_summaries.csv', 'strata_contrasts_descriptive.csv', 'internal_EXAONE_cells.csv', 'internal_EXAONE_arm_summaries.csv', 'internal_EXAONE_L_W_L_P_descriptive.csv', 'internal_EXAONE_S_references_descriptive.csv')}, 'apeach': {'cli': 'APEACH', 'family': 'new_APEACH_assignment_controls_8', 'directory': 'data/apeach_controls_20261010', 'files': ('cells.csv', 'arm_summaries.csv', 'primary.csv', 'S_references_descriptive.csv', 'writer_topic_cells.csv', 'writer_topic_summaries.csv', 'writer_topic_contrasts_descriptive.csv')}, 'policy_AB': {'cli': 'POLICY_AB', 'family': 'new_policy_boundary_total_learning_12', 'directory': 'data/policy_boundary_20261010', 'files': ('cells.csv', 'arm_summaries.csv', 'primary.csv', 'strata_cells.csv', 'strata_summaries.csv', 'strata_contrasts_descriptive.csv', 'annotation_turnover_summary.csv', 'annotation_turnover_by_repetition.csv', 'native2000_diagnostic_cells.csv', 'native2000_diagnostic_binary_transitions_by_reference_class.csv', 'native2000_diagnostic_all13_score_distributions.csv', 'native2000_diagnostic_teacher_target_presence.csv')}}
    new_studies = {}
    for kind, spec in new_specs.items():
        family_output = output / kind
        family_output.mkdir(parents=True, exist_ok=False)
        checked = subprocess.run([sys.executable, "-I", "-B", str(ROOT / "reproduce_new_families.py"),
                                  "--family", spec["cli"], "--data", str(ROOT / spec["directory"]),
                                  "--output", str(family_output / "verification.json")],
                                 cwd=ROOT.parent, env=env, capture_output=True, text=True, timeout=120)
        if checked.returncode:
            raise RuntimeError("New-family " + kind + " numerical verification failed: " + checked.stderr[-1000:])
        report = json.loads((family_output / "verification.json").read_text())
        if (report.get("status") != "PASS" or report.get("family_identity") != spec["cli"]
                or report.get("family") != spec["family"]):
            raise ValueError("Wrong or incomplete new-family arithmetic result")
        listed = report.get("input_files", [])
        observed = {}
        for item in listed:
            if (set(item) != {"path", "bytes", "sha256"} or item["path"] not in spec["files"]
                    or item["path"] in observed):
                raise ValueError("Wrong or duplicate new-family arithmetic input")
            observed[item["path"]] = {"bytes": item["bytes"], "sha256": item["sha256"]}
        expected = {name: {"bytes": (ROOT / spec["directory"] / name).stat().st_size,
                          "sha256": hashlib.sha256((ROOT / spec["directory"] / name).read_bytes()).hexdigest()}
                    for name in spec["files"]}
        if observed != expected:
            raise ValueError("New-family checker did not verify its complete actual input bytes")
        new_studies[kind] = report
    if verify_checksums() != checksum_report:
        raise ValueError("Verification modified the companion payload")
    report = {"status": "PASS", "availability": "Prepared locally; not published externally by this export.",
              "complete_checksums": checksum_report, "historical": historical, "cpu_20261010": cpu,
              "additional_gemma_control_extension": {"status": "included_aggregate_check_passed",
                  "cell_rows": gemma["cell_rows"], "target_rows": gemma["target_rows"],
                  "scope": "New Gemma S/L/W/P; separate4macro/14target families;6descriptive rows."},
              "gemma_20261010": gemma,
              "new_studies": new_studies,
              "new_training_or_model_calls": 0}
    (output / "verification.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": report["status"], "payload_files": checksum_report["payload_files"],
                      "historical_status": historical["status"], "cpu_status": cpu["status"],
                      "additional_gemma_control_extension": report["additional_gemma_control_extension"]}, indent=2))


if __name__ == "__main__":
    main()

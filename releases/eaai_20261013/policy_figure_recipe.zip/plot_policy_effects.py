"""Draw the complete policy B-A macro-F1 family from a released aggregate CSV.

Saved estimates, confidence intervals and adjusted probabilities are displayed
without recalculating tests. Only the aggregate file and bundled style are read.
"""
from __future__ import annotations

import argparse
import ast
import csv
from io import StringIO
import hashlib
import json
import math
import os
from pathlib import Path

CORPORA = ("KHATERS", "KOLD", "APEACH")
PATHS = ("exaone", "gemma4")
MODELS = ("kcelectra", "xlmr")
SEEDS = tuple(map(str, range(20260901, 20260924)))
EXPECTED = tuple((c, p, m) for c in CORPORA for p in PATHS for m in MODELS)
SUPPORT = {"KHATERS": (9997, 6799, 3198), "KOLD": (40129, 27776, 12353),
           "APEACH": (3767, 1848, 1919)}
NAMES = {"KHATERS": "K-HATERS", "KOLD": "KOLD", "APEACH": "APEACH",
         "exaone": "EXAONE", "gemma4": "Gemma", "kcelectra": "KcELECTRA", "xlmr": "XLM-R"}
MARKERS = {"kcelectra": "o", "xlmr": "s"}
WIDTH_MM, HEIGHT_MM = 160, 118
SCHEMA = ("corpus", "path", "model", "contrast", "metric", "primary", "n", "mean", "sd",
          "ci95_pointwise", "p_raw", "t_test_defined", "values_by_seed", "p_holm_12", "Holm_slot_used")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(text, *, nullable=False):
    if nullable and text == "":
        return None
    value = float(text)
    require(math.isfinite(value), "Nonfinite numeric aggregate")
    return value


def boolean(text):
    require(text in ("True", "False"), "Expected literal Boolean aggregate")
    return text == "True"


def literal(text):
    require(isinstance(text, str) and len(text) <= 16384, "Invalid aggregate literal")
    try:
        tree = ast.parse(text, mode="eval")
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                keys = [ast.literal_eval(key) for key in node.keys]
                require(len(keys) == len(set(keys)), "Duplicate aggregate dictionary key")
        return ast.literal_eval(tree)
    except (SyntaxError, TypeError, ValueError) as exc:
        raise ValueError("Invalid aggregate literal") from exc


def load_rows(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), "Aggregate CSV must be a regular file")
    payload = path.read_bytes()
    reader = csv.DictReader(StringIO(payload.decode("utf-8")))
    require(reader.fieldnames is not None and len(reader.fieldnames) == len(SCHEMA)
            and set(reader.fieldnames) == set(SCHEMA), "Complete primary aggregate schema required")
    rows = []
    for raw in reader:
        require(None not in raw and all(value is not None for value in raw.values()), "Malformed CSV row")
        row = {key: raw[key] for key in ("corpus", "path", "model", "contrast", "metric")}
        require(raw["n"] == "23", "Exactly23 paired repeats required")
        row["n"] = 23
        for key in ("primary", "t_test_defined", "Holm_slot_used"):
            row[key] = boolean(raw[key])
        for key in ("mean", "sd", "p_raw", "p_holm_12"):
            row[key] = number(raw[key], nullable=key.startswith("p_"))
        row["ci95_pointwise"] = literal(raw["ci95_pointwise"])
        row["values_by_seed"] = literal(raw["values_by_seed"])
        rows.append(row)
    require(len(rows) == 12 and tuple((r["corpus"], r["path"], r["model"]) for r in rows) == EXPECTED,
            "All12 contrasts required in the released source order")
    for row in rows:
        require(row["contrast"] == "B-A" and row["metric"] == "macro_f1"
                and row["primary"] and row["Holm_slot_used"], "Wrong complete inference family")
        values = row["values_by_seed"]
        require(isinstance(values, dict) and tuple(values) == SEEDS
                and all(type(value) in (int, float) and math.isfinite(value) and -1 <= value <= 1
                        for value in values.values()), "All23 finite ordered paired differences required")
        require(-1 <= row["mean"] <= 1 and row["sd"] >= 0, "Invalid effect mean or SD")
        ci = row["ci95_pointwise"]
        require(isinstance(ci, list) and len(ci) == 2
                and all(type(value) in (int, float) and math.isfinite(value) for value in ci)
                and ci[0] <= row["mean"] <= ci[1], "Invalid pointwise interval")
        for key in ("p_raw", "p_holm_12"):
            require(row[key] is None or 0 <= row[key] <= 1, "Probability outside [0,1]")
        require((row["p_raw"] is None) == (row["p_holm_12"] is None), "Undefined slot must remain undefined")
        require(row["t_test_defined"] == (row["sd"] != 0), "Saved test definition differs from saved variance")
        require(not row["t_test_defined"] or row["p_raw"] is not None, "Defined test requires saved probability")
    return rows, {"file": path.name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}


def probability_label(value):
    if value is None:
        return "—"
    if value < .05 and round(value, 4) >= .05:
        return "< .05"
    return "< .0001" if value < .0001 else f"{value:.4f}"


def output_guard(destination):
    destination = Path(destination).absolute()
    require(destination.resolve(strict=False) == destination, "Output contains a symlink or traversal")
    require(not os.path.lexists(destination), "Existing output is preserved")
    for parent in destination.parents:
        if os.path.lexists(parent):
            require(parent.is_dir() and not parent.is_symlink(), "Output parent is not a regular directory")
    return destination


def draw(rows, populations, fs):
    """Retained complete12-point drawing; all numbers remain source values."""
    import matplotlib
    from matplotlib.lines import Line2D
    import matplotlib.ticker as ticker

    fig = fs.figure(width_mm=WIDTH_MM, height_mm=HEIGHT_MM)
    ax = fig.add_axes([.285, .225, .565, .635])
    ys = [i + .9 * (i // 4) for i in range(12)]
    extent = max(abs(endpoint) for r in rows for endpoint in r["ci95_pointwise"])
    # Equal distance on either side of zero; all source intervals are included.
    bound = max(.01, extent * 1.12)
    for index, corpus in enumerate(CORPORA):
        start = 4 * index
        first, last = ys[start], ys[start + 3]
        ax.axhspan(first - .48, last + .48,
                   color=fs.COLORS["surface"] if index % 2 == 0 else fs.COLORS["background"], zorder=0)
        ax.text(-.475, first - .63, f"{NAMES[corpus]} · n = {populations[corpus]['n']:,}",
                transform=ax.get_yaxis_transform(), fontsize=fs.STYLE["type_pt"]["body"],
                weight=fs.STRONG_WEIGHT, va="bottom")
    for y, row in zip(ys, rows, strict=True):
        lo, hi = row["ci95_pointwise"]
        color = fs.COLORS[row["path"]]
        value = row["p_holm_12"]
        significant = value is not None and value < .05
        ax.errorbar(row["mean"], y,
                    xerr=[[row["mean"] - lo], [hi - row["mean"]]],
                    fmt=MARKERS[row["model"]], color=color,
                    mfc=color if significant else fs.COLORS["background"],
                    ms=fs.STYLE["marker"]["size_pt"], capsize=2,
                    elinewidth=fs.STYLE["line_pt"]["ci"],
                    markeredgewidth=fs.STYLE["marker"]["edge_pt"], zorder=3)
        ax.text(1.22, y, probability_label(value), transform=ax.get_yaxis_transform(),
                ha="right", va="center", fontsize=fs.STYLE["type_pt"]["tick"])
    ax.axvline(0, color=fs.COLORS["muted"], ls="--", lw=fs.STYLE["line_pt"]["connector"], zorder=1)
    ax.set(xlim=(-bound, bound), ylim=(ys[-1] + .8, -1.1), yticks=ys,
           yticklabels=[f"{NAMES[r['path']]} / {NAMES[r['model']]}" for r in rows],
           xlabel="Macro-F1 difference: B − A")
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=5, symmetric=True))
    ax.xaxis.set_major_formatter(ticker.StrMethodFormatter("{x:.3f}"))
    ax.tick_params(axis="y", labelsize=fs.STYLE["type_pt"]["label"])
    fs.clean_axis(ax)
    fig.text(.02, .978, "Clarifying the inclusion boundary: B − A learning effects",
             fontsize=fs.STYLE["type_pt"]["panel"], weight=fs.STRONG_WEIGHT, va="top")
    fig.text(.976, .883, "Holm12 p", ha="right", fontsize=fs.STYLE["type_pt"]["tick"], weight=fs.STRONG_WEIGHT)
    fig.legend(handles=[
        Line2D([], [], color=fs.COLORS["exaone"], lw=1.2, label="EXAONE pathway"),
        Line2D([], [], color=fs.COLORS["gemma4"], lw=1.2, label="Gemma pathway"),
        Line2D([], [], marker="o", color=fs.COLORS["ink"], lw=0, label="KcELECTRA"),
        Line2D([], [], marker="s", color=fs.COLORS["ink"], lw=0, label="XLM-R"),
    ], loc="upper center", bbox_to_anchor=(.5, .16), ncol=4,
        handlelength=1.2, handletextpad=.4, columnspacing=1.1,
        fontsize=fs.STYLE["type_pt"]["legend"])
    fig.text(.02, .082, "Pointwise 95% paired t intervals · 23 matched training repeats · One Holm family of 12",
             fontsize=fs.STYLE["type_pt"]["tick"], color=fs.COLORS["muted"])
    fig.text(.02, .047, "Filled: Holm p < .05 · Open: p ≥ .05 or undefined (—) · Three fixed evaluation corpora",
             fontsize=fs.STYLE["type_pt"]["tick"], color=fs.COLORS["muted"])
    fig.canvas.draw()
    text_sizes = [obj.get_fontsize() for obj in fig.findobj(matplotlib.text.Text)
                  if obj.get_visible() and obj.get_text()]
    require(text_sizes and min(text_sizes) >= 7, "Some visible native text is smaller than 7 pt")
    return fig, {"minimum_visible_font_pt": min(text_sizes), "x_limits_shared": [-bound, bound]}



def build(input_csv, output, *, synthetic=False):
    output = output_guard(output)
    rows, source = load_rows(input_csv)
    import matplotlib
    import plot_style as fs

    require(matplotlib.__version__ == "3.11.1", "Matplotlib3.11.1 is required for this figure recipe")
    require(fs.STYLE["type_pt"]["minimum"] >= 7, "Figure minimum font must remain7pt")
    populations = {c: {"n": n, "negative_reference_n": n0, "positive_reference_n": n1}
                   for c, (n, n0, n1) in SUPPORT.items()}
    fig, display = draw(rows, populations, fs)
    if synthetic:
        fig.text(.5, .01, "SYNTHETIC TEST FIXTURE — NOT STUDY RESULTS", ha="center", fontsize=7)
    fs.validate_canvas(fig)
    current = Path(input_csv).read_bytes()
    require(len(current) == source["bytes"] and hashlib.sha256(current).hexdigest() == source["sha256"],
            "Aggregate CSV changed during rendering")
    output = output_guard(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.mkdir()
    fs.save(fig, output / "policy_boundary_total_learning")
    outputs = []
    for extension in (".pdf", ".svg", ".png"):
        path = output / ("policy_boundary_total_learning" + extension)
        outputs.append({"file": path.name, "bytes": path.stat().st_size,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    receipt = {"kind": "synthetic_test_fixture" if synthetic else "aggregate_figure_reproduction",
               "input": source, "rows": rows, "family_size": 12, "paired_repetitions": 23,
               "contrast": "B-A", "metric": "macro_f1", "width_mm": WIDTH_MM, "height_mm": HEIGHT_MM,
               **display, "population": populations, "statistical_tests_recomputed": False, "outputs": outputs}
    (output / "plot_data.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", required=True, type=Path, help="Released policy macro-differences aggregate CSV")
    parser.add_argument("--out", required=True, type=Path, help="New output directory; existing directories are refused")
    parser.add_argument("--synthetic", action="store_true", help="Mark an intentionally synthetic test fixture")
    args = parser.parse_args()
    result = build(args.csv, args.out, synthetic=args.synthetic)
    print(json.dumps({"kind": result["kind"], "input": result["input"], "outputs": result["outputs"]}, indent=2))


if __name__ == "__main__":
    main()

"""Standalone figure style; local recipe consumes figure_style.json.

Widths and point sizes describe the actual PDF insertion size, not a poster.
No experimental or statistical computation is performed here.
"""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parent
STYLE_PATH = ROOT / "figure_style.json"
STYLE = json.loads(STYLE_PATH.read_text())
STRONG_WEIGHT = STYLE.get("font_weights", {}).get("strong", 700)
COLORS = dict(STYLE["palette"])
COLORS.update({role: COLORS[spec["color_token"]] for role, spec in STYLE["role_map"].items()})


def register_fonts():
    """Load the exact project font files into Matplotlib's font registry."""
    for relative in STYLE.get("font_assets", []):
        path = ROOT / relative
        if not path.is_file():
            raise FileNotFoundError(f"Missing bundled figure font: {path}")
        font_manager.fontManager.addfont(path)


def svg_font_family(strong=False, cjk=False):
    # An explicit static face keeps SVG, Cairo and editable PPT output on the
    # same real600-weight outlines instead of synthesizing a bold variant.
    key = ("strong_cjk" if cjk else "strong_latin") if strong else ("cjk" if cjk else "latin")
    return STYLE["fonts"].get(key, STYLE["fonts"]["cjk" if cjk else "latin"])


def panel_label(letter):
    """Separate panel identifiers from English titles and grammatical articles."""
    if len(letter) != 1 or letter not in "abcdefghijklmnopqrstuvwxyz":
        raise ValueError(f"Expected one lowercase panel letter; got {letter!r}")
    return STYLE["notation"]["panel_label_format"].format(letter=letter)


def configure():
    # Fail on a missing requested font rather than silently changing the paper.
    register_fonts()
    families = list(dict.fromkeys(STYLE["fonts"][key] for key in ["latin", "cjk", "symbols"]))
    for family in families:
        font_manager.findfont(family, fallback_to_default=False)
    plt.rcParams.update({
        "font.family": families + STYLE["fonts"]["fallbacks"],
        "font.weight": STYLE.get("font_weights", {}).get("regular", 400),
        "axes.titleweight": STRONG_WEIGHT,
        "font.size": STYLE["type_pt"]["body"],
        "axes.labelsize": STYLE["type_pt"]["label"],
        "xtick.labelsize": STYLE["type_pt"]["tick"],
        "ytick.labelsize": STYLE["type_pt"]["tick"],
        "legend.fontsize": STYLE["type_pt"]["legend"],
        "text.color": COLORS["ink"], "axes.labelcolor": COLORS["ink"],
        "xtick.color": COLORS["muted"], "ytick.color": COLORS["muted"],
        "axes.edgecolor": COLORS["line"], "axes.linewidth": STYLE["line_pt"]["axis"],
        "figure.facecolor": COLORS["background"], "axes.facecolor": COLORS["background"],
        "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42,
        "svg.fonttype": "none", "savefig.bbox": None,
    })


def figure(width_mm=None, height_mm=100, **kwargs):
    configure()
    width_mm = STYLE["figure_mm"]["double_column"] if width_mm is None else width_mm
    return plt.figure(figsize=(width_mm / 25.4, height_mm / 25.4), **kwargs)


def clean_axis(ax):
    for side in ["left", "top", "right"]:
        ax.spines[side].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=5)
    ax.grid(False)


def save(fig, path):
    """Keep exact physical dimensions; PDF for print, editable SVG, PNG preview."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    validate_canvas(fig)
    fig.savefig(path.with_suffix(".pdf"), metadata={"Creator": "Matplotlib"})
    fig.savefig(path.with_suffix(".svg"))
    fig.savefig(path.with_suffix(".png"), dpi=STYLE["publication_export"]["dpi"])
    plt.close(fig)



def validate_canvas(fig):
    # Canvas overflow is an error, not something to hide with bbox_inches=tight.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    canvas = fig.bbox
    # Matplotlib 3.11.1 retains labels for locator ticks outside the view,
    # although Axis.draw only draws the ticks returned by _update_ticks().
    undrawn_tick_labels = set()
    for ax in fig.axes:
        for axis in (ax.xaxis, ax.yaxis):
            drawn_ticks = set(axis._update_ticks())
            for tick in axis.majorTicks + axis.minorTicks:
                if tick not in drawn_ticks:
                    undrawn_tick_labels.update((tick.label1, tick.label2))
    for obj in fig.findobj(matplotlib.text.Text):
        if obj in undrawn_tick_labels or not obj.get_visible() or not obj.get_text():
            continue
        box = obj.get_window_extent(renderer)
        if box.x0 < -1 or box.y0 < -1 or box.x1 > canvas.x1 + 1 or box.y1 > canvas.y1 + 1:
            raise ValueError(f"Text outside figure: {obj.get_text()!r}")

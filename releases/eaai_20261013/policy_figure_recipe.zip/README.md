# Policy boundary effect figure

This standalone recipe displays the complete twelve B−A macro-F1 comparisons from the released aggregate table. It requires Python 3.11 or newer, Matplotlib 3.11.1, and the bundled Pretendard fonts. The reference rendering environment uses Python 3.12.3 (with NumPy 2.5.1, which requires Python 3.12 or newer). It reads no item-level labels, texts, predictions, checkpoints, project modules or remote services.

Install the plotting dependency and provide the released CSV explicitly:

```sh
python -m pip install -r requirements.txt
python plot_policy_effects.py --csv policy_macro_differences.csv --out reproduced_policy_plot
```

The input has the producer's `primary.csv` schema. `policy_macro_differences.csv` is a possible public filename alias; renaming must preserve the bytes and header. A released `primary.csv` can be passed directly. No data are included in this recipe and no file is searched for automatically. A missing or incomplete input is refused before an output directory is created.

The exact columns are:

```text
corpus,path,model,contrast,metric,primary,n,mean,sd,ci95_pointwise,p_raw,t_test_defined,values_by_seed,p_holm_12,Holm_slot_used
```

All twelve rows are required in corpus order K-HATERS, KOLD, APEACH; within each corpus, EXAONE/KcELECTRA, EXAONE/XLM-R, Gemma/KcELECTRA, Gemma/XLM-R. The stored contrast is `B-A`, metric `macro_f1`, and both primary-family flags are `True`. Each row contains all 23 ordered repeat keys 20260901–20260923 in `values_by_seed`. Intervals are the saved two-element `ci95_pointwise` lists. Nested fields use the producer's literal-list/dictionary encoding. Blank probability cells preserve undefined tests.

The code checks the display schema and complete family. It displays the supplied mean, pointwise95% paired t interval and Holm 12 probability without recomputing them. Aggregate arithmetic and agreement with underlying predictions must be established separately; this plot cannot establish either. The three corpora evaluate the same fitted models, so they are not three independent sets of training repeats.

Outputs are PDF, SVG, a 1000 dpi PNG preview and `plot_data.json`, which preserves the plotted values and input-byte hash. Dimensions are 160×118 mm, visible text is at least 7 pt, ticks use three decimals, all twelve intervals share one symmetric axis and zero is retained. Colors identify pathways, shapes identify classifiers, filled markers mean Holm p<.05, and an em dash preserves an undefined probability. Favorable, adverse, zero and nonsignificant effects remain in the figure. The saved interval is pointwise; significance comes from one complete Holm 12 family.

The output directory must be new. Existing files/directories and symbolic output paths are refused. Use a different destination for a new reproduction. `--synthetic` adds an explicit synthetic-fixture watermark when testing this recipe with intentionally made-up aggregate values; omit it for a released study table.

The plotted comparison estimates the full four-clause instruction-boundary bundle effect. It does not identify individual-clause effects or independently validate translated semantic accuracy. The fonts are distributed under the included SIL Open Font License in `fonts/OFL.txt`.

The full figure caption is provided in `caption.txt`.
